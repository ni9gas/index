import requests, json, threading, time, os, random
from colorama import Fore, init

init()

# Load settings from settings.json
def openConfig():
    with open("./settings.json", "r") as config:
        settingsList = json.load(config)
    return settingsList

settings = openConfig()
ComboList = settings["Settings"]["List"]
useProxies = settings["Settings"]["useProxies"]
proxyList = settings["Settings"]["Proxies"]
delimiter = settings["Settings"]["Delimiter"]
threadcount = settings["Settings"]["Threads"]

def getProxiesFromFile(proxy_file):
    """Reads proxies from the specified file."""
    with open(proxy_file, "r") as file:
        proxies = file.read().splitlines()
    return proxies

def grabProxy():
    """Grabs a random proxy from the loaded list."""
    if useProxies and getProxies:
        return random.choice(getProxies)
    return None

if useProxies:
    getProxies = getProxiesFromFile(proxyList)
else:
    getProxies = []

class Vars:
    """Class to manage state and variables."""
    registered, cpm, bad, checks = 0, 0, 0, 0
    emails = []
    processed_emails = set()
    lock = threading.Lock()

    @staticmethod
    def loadProcessedEmails():
        """Load already processed emails to avoid duplication."""
        if os.path.exists("./processed_emails.txt"):
            with open("./processed_emails.txt", "r", encoding="utf-8") as file:
                Vars.processed_emails = set(file.read().splitlines())

    @staticmethod
    def saveProcessedEmail(email):
        """Save processed email to prevent duplication."""
        with open("./processed_emails.txt", "a+", encoding="utf-8") as file:
            file.write(f"{email}\n")

    @staticmethod
    def saveRegisteredEmail(email):
        """Save registered email to registered.txt."""
        with open("./registered.txt", "a+", encoding="utf-8") as file:
            file.write(f"{email}\n")

    @staticmethod
    def worker(thread_id):
        """Thread worker function."""
        while True:
            Vars.lock.acquire()
            if Vars.emails:
                email = Vars.emails.pop(0)
                if email in Vars.processed_emails:
                    Vars.lock.release()
                    continue
                Vars.processed_emails.add(email)
                Vars.saveProcessedEmail(email)
                Vars.lock.release()

                # Perform the API check
                Checker.checkEmail(email)
            else:
                Vars.lock.release()
                break

    @staticmethod
    def main():
        """Main function to manage threads."""
        Vars.loadProcessedEmails()

        with open(ComboList, "r", encoding="utf-8") as f:
            if delimiter:
                all_emails = [l.split(delimiter)[0].strip() if delimiter in l else l.strip() for l in f]
            else:
                all_emails = [l.strip() for l in f]

        Vars.emails = [email for email in all_emails if email not in Vars.processed_emails]

        threading.Thread(target=Vars.cpmCounter, daemon=True).start()
        threading.Thread(target=Vars.updateTitle, daemon=True).start()
        threads = []

        for i in range(threadcount):
            t = threading.Thread(target=Vars.worker, args=(i,))
            threads.append(t)
            t.start()

        for t in threads:
            t.join()

    @staticmethod
    def cpmCounter():
        """Count checks per minute."""
        while True:
            old = Vars.checks
            time.sleep(2)
            new = Vars.checks
            Vars.cpm = (new - old) * 30

    def updateTitle():
        """Update the terminal title."""
        start = time.time()
        total_emails = len(Vars.emails) + len(Vars.processed_emails)
        while True:
            elapsed = time.strftime("%H:%M:%S", time.gmtime(time.time() - start))
            os.system(f"title Email Checker - {Vars.checks}/{total_emails} - Registered: {Vars.registered} - CPM: {Vars.cpm} - Time Elapsed: {elapsed}")
            time.sleep(0.4)

class Checker:
    """Checker class to interact with the email-check API."""

    @staticmethod
    def checkEmail(email):
        """Check if the email is registered using the API."""
        try:
            proxy = grabProxy()
            proxies = {"http": f"http://{proxy}", "https": f"http://{proxy}"} if proxy else None

            response = requests.post(
                "https://prod-api.154310543964.hellopublic.com/userservice/public/email-check",
                headers={
                    "accept": "*/*",
                    "accept-language": "en-US,en;q=0.6",
                    "content-type": "application/json",
                    "dnt": "1",
                    "origin": "https://public.com",
                    "priority": "u=1, i",
                    "sec-ch-ua": '"Brave";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
                    "sec-ch-ua-mobile": "?0",
                    "sec-ch-ua-platform": '"Windows"',
                    "sec-fetch-dest": "empty",
                    "sec-fetch-mode": "cors",
                    "sec-fetch-site": "cross-site",
                    "sec-gpc": "1",
                    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                    "x-app-version": "web-1.0.9",
                },
                json={"email": email},
                proxies=proxies,
                timeout=60
            )

            Vars.lock.acquire()
            Vars.checks += 1

            if response.status_code == 200:
                result = response.json()
                if result.get("available") is False:
                    print(f"{Fore.GREEN}>{Fore.WHITE} {email} registered!")
                    Vars.saveRegisteredEmail(email)
                    Vars.registered += 1
                else:
                    Vars.bad += 1
            else:
                Vars.bad += 1
        except Exception as e:
            print(f"{Fore.RED}Error checking {email}: {e}")
        finally:
            if Vars.lock.locked():
                Vars.lock.release()

if __name__ == "__main__":
    Vars.main()
