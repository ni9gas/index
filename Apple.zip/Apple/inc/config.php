<?php
	date_default_timezone_set('Europe/London');
	
	/* UPDATE THESE 3 LINES */
	$OUR_ROOT_LINK = 'https://yoururlhere.com';
	$OUR_404_PAGE = 'https://apple.com';
	$ownerEmail = 'youremailhere@example.com';

	$CURRENT_PAGE = basename($_SERVER['PHP_SELF']);
	$currentDate = date('Y-m-d H:i:s');
	$USER_AGENT = $_SERVER['HTTP_USER_AGENT'];

?>