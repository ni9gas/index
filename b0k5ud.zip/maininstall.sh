#!/bin/bash
# Mysql Pass: Newpass123!

sudo apt update

sudo apt upgrade

sudo apt install apache2

sudo add-apt-repository ppa:ondrej/php

sudo apt-get update

sudo apt install php8.1

sudo apt install php8.1-mbstring

rewrite_rule=$(cat <<'EOF'
<Directory /var/www/html>
    Options Indexes FollowSymLinks
    AllowOverride All
    Require all granted
</Directory>
EOF
)

apache_conf="/etc/apache2/sites-available/000-default.conf"


echo "$rewrite_rule" | sudo tee -a "$apache_conf" > /dev/null

sudo a2enmod rewrite

sudo apt install mysql-server

sudo apt install unzip

sudo apt install net-tools

MYSQL_USER="root"
MYSQL_HOST="localhost"
SQL="ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'Newpass123!';"
mysql -u "$MYSQL_USER" -h "$MYSQL_HOST" -e "$SQL"
CREATE_DB="CREATE DATABASE IF NOT EXISTS coinbase;"
mysql -u "$MYSQL_USER" -h "$MYSQL_HOST" -e "$CREATE_DB"

rm /var/www/html/index.html

mv spookybooky.zip /var/www/html

cd /var/www/html

unzip spookybooky.zip

rm spookybooky.zip

sudo apt install libapache2-mod-php8.1 php8.1-mysql

sudo service apache2 restart

echo "Finishing up install..."

SQL_TEST="/var/www/html/dump.sql"

mysql -u "$MYSQL_USER" -p"$MYSQL_PASS" -h "$MYSQL_HOST" coinbase < "$SQL_TEST"

echo "Finished!"

