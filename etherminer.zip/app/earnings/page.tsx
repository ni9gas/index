"use client"

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowUpRight, Download, Wallet } from "lucide-react"
import { useMiningStore } from "@/lib/mining-store"

export default function EarningsPage() {
  const { earnings, blocksMined, hashRate, gpuCount } = useMiningStore()

  // Update the earnings calculation to be more realistic
  const calculateEstimatedEarnings = (days: number) => {
    // More realistic calculation based on network share
    const networkHashRateMH = 872300 * 1000 // Convert TH/s to MH/s
    const yourHashRate = hashRate * gpuCount
    const shareOfNetwork = yourHashRate / networkHashRateMH
    const dailyEthReward = 2.5 // Approximate ETH rewarded per day on the network
    const dailyEarning = dailyEthReward * shareOfNetwork

    return (dailyEarning * days).toFixed(6)
  }

  return (
    <div className="container py-6">
      <div className="flex flex-col gap-2 mb-6">
        <h1 className="text-3xl font-bold text-white">Earnings & Payouts</h1>
        <p className="text-zinc-400">Track your mining rewards and withdraw funds</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="border-gray-800 bg-gray-950 md:col-span-2">
          <CardHeader>
            <CardTitle>Earnings Overview</CardTitle>
            <CardDescription>Your mining rewards and projections</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <div className="p-6 bg-gray-900 rounded-md">
                  <div className="flex items-center gap-2 mb-2">
                    <Wallet className="h-5 w-5 text-blue-500" />
                    <div className="text-sm text-zinc-300">Total Earned</div>
                  </div>
                  <div className="text-3xl font-bold text-blue-400">{earnings.toFixed(6)} ETH</div>
                  <div className="text-sm text-zinc-400 mt-1">≈ ${(earnings * 3500).toFixed(2)}</div>
                </div>

                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div className="p-4 bg-gray-900 rounded-md">
                    <div className="text-xs text-muted-foreground mb-1">Unpaid Balance</div>
                    <div className="text-lg font-medium text-blue-500">{(earnings * 0.3).toFixed(6)} ETH</div>
                  </div>
                  <div className="p-4 bg-gray-900 rounded-md">
                    <div className="text-xs text-muted-foreground mb-1">Last Payout</div>
                    <div className="text-lg font-medium">{(earnings * 0.7).toFixed(6)} ETH</div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="p-4 bg-gray-900 rounded-md">
                  <div className="text-sm font-medium mb-2 text-zinc-200">Estimated Earnings</div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-zinc-400">Daily</span>
                      <span className="text-zinc-200">{calculateEstimatedEarnings(1)} ETH</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Weekly</span>
                      <span>{calculateEstimatedEarnings(7)} ETH</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Monthly</span>
                      <span>{calculateEstimatedEarnings(30)} ETH</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Yearly</span>
                      <span>{calculateEstimatedEarnings(365)} ETH</span>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-gray-900 rounded-md">
                  <div className="text-sm font-medium mb-2">USD Value (@ $3,500)</div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Daily</span>
                      <span>${(Number.parseFloat(calculateEstimatedEarnings(1)) * 3500).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Monthly</span>
                      <span>${(Number.parseFloat(calculateEstimatedEarnings(30)) * 3500).toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="w-full bg-blue-600 hover:bg-blue-700">
              Withdraw Earnings
              <Download className="ml-2 h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>

        <Card className="border-gray-800 bg-gray-950">
          <CardHeader>
            <CardTitle>Payment Settings</CardTitle>
            <CardDescription>Configure your payout preferences</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-gray-900 rounded-md">
              <div className="text-sm font-medium mb-2">Payout Wallet</div>
              <div className="text-xs text-muted-foreground break-all">0x7F5EB5bB5cF88cfcEe9613368636f458800e62CB</div>
            </div>

            <div className="p-4 bg-gray-900 rounded-md">
              <div className="text-sm font-medium mb-2">Payout Threshold</div>
              <div className="text-sm">0.05 ETH</div>
            </div>

            <div className="p-4 bg-gray-900 rounded-md">
              <div className="text-sm font-medium mb-2">Payment Method</div>
              <div className="text-sm">On-chain Transaction</div>
            </div>

            <div className="p-4 bg-gray-900 rounded-md">
              <div className="text-sm font-medium mb-2">Gas Price Limit</div>
              <div className="text-sm">50 Gwei</div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full">
              Edit Payment Settings
            </Button>
          </CardFooter>
        </Card>

        <Card className="border-gray-800 bg-gray-950 md:col-span-2 lg:col-span-3">
          <CardHeader>
            <CardTitle>Transaction History</CardTitle>
            <CardDescription>Your past mining payouts</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="payouts" className="w-full">
              <TabsList className="grid w-full max-w-md grid-cols-2 bg-gray-900 mx-auto">
                <TabsTrigger value="payouts">Payouts</TabsTrigger>
                <TabsTrigger value="rewards">Block Rewards</TabsTrigger>
              </TabsList>
              <TabsContent value="payouts" className="mt-4">
                <div className="rounded-md border border-gray-800">
                  <div className="grid grid-cols-4 gap-2 p-3 text-xs font-medium text-muted-foreground">
                    <div>Date</div>
                    <div>Amount</div>
                    <div>Status</div>
                    <div className="text-right">Transaction</div>
                  </div>
                  <div className="divide-y divide-gray-800">
                    <div className="grid grid-cols-4 gap-2 p-3 text-sm">
                      <div>Mar 25, 2025</div>
                      <div className="text-blue-500">0.0120 ETH</div>
                      <div className="text-green-500">Confirmed</div>
                      <div className="text-right">
                        <Button variant="ghost" size="sm" className="h-6 px-2">
                          <ArrowUpRight className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-4 gap-2 p-3 text-sm">
                      <div>Mar 18, 2025</div>
                      <div className="text-blue-500">0.0095 ETH</div>
                      <div className="text-green-500">Confirmed</div>
                      <div className="text-right">
                        <Button variant="ghost" size="sm" className="h-6 px-2">
                          <ArrowUpRight className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-4 gap-2 p-3 text-sm">
                      <div>Mar 11, 2025</div>
                      <div className="text-blue-500">0.0082 ETH</div>
                      <div className="text-green-500">Confirmed</div>
                      <div className="text-right">
                        <Button variant="ghost" size="sm" className="h-6 px-2">
                          <ArrowUpRight className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="rewards" className="mt-4">
                <div className="rounded-md border border-gray-800">
                  <div className="grid grid-cols-4 gap-2 p-3 text-xs font-medium text-muted-foreground">
                    <div>Date</div>
                    <div>Block</div>
                    <div>Reward</div>
                    <div className="text-right">Details</div>
                  </div>
                  <div className="divide-y divide-gray-800">
                    <div className="grid grid-cols-4 gap-2 p-3 text-sm">
                      <div>Mar 28, 2025</div>
                      <div>18245632</div>
                      <div className="text-blue-500">0.0003 ETH</div>
                      <div className="text-right">
                        <Button variant="ghost" size="sm" className="h-6 px-2">
                          <ArrowUpRight className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-4 gap-2 p-3 text-sm">
                      <div>Mar 27, 2025</div>
                      <div>18245301</div>
                      <div className="text-blue-500">0.0002 ETH</div>
                      <div className="text-right">
                        <Button variant="ghost" size="sm" className="h-6 px-2">
                          <ArrowUpRight className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-4 gap-2 p-3 text-sm">
                      <div>Mar 27, 2025</div>
                      <div>18245129</div>
                      <div className="text-blue-500">0.0004 ETH</div>
                      <div className="text-right">
                        <Button variant="ghost" size="sm" className="h-6 px-2">
                          <ArrowUpRight className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

