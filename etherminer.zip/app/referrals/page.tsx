"use client"

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ArrowRight, Copy, Share2, Users } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { useState } from "react"

export default function ReferralsPage() {
  const [referralCode] = useState("ETH" + Math.random().toString(36).substring(2, 8).toUpperCase())

  const copyReferralCode = () => {
    navigator.clipboard.writeText(referralCode)
    toast({
      title: "Referral Code Copied",
      description: "Share with friends to earn bonus rewards!",
    })
  }

  const copyReferralLink = () => {
    navigator.clipboard.writeText(`https://ethsim.io/ref/${referralCode}`)
    toast({
      title: "Referral Link Copied",
      description: "Link copied to clipboard.",
    })
  }

  return (
    <div className="container py-6">
      <div className="flex flex-col gap-2 mb-6">
        <h1 className="text-3xl font-bold text-white">Referral Program</h1>
        <p className="text-zinc-400">Invite friends to join and earn 10% of their mining rewards forever</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="border-gray-800 bg-gray-950">
          <CardHeader>
            <CardTitle>Your Referral Link</CardTitle>
            <CardDescription>Share this link with friends to earn rewards</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-2 p-3 bg-gray-900 rounded-md">
              <span className="text-sm font-medium truncate flex-1 text-zinc-200">
                https://ethsim.io/ref/{referralCode}
              </span>
              <Button variant="outline" size="sm" onClick={copyReferralLink}>
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex items-center gap-2 p-3 bg-gray-900 rounded-md">
              <span className="text-sm font-medium truncate flex-1">Code: {referralCode}</span>
              <Button variant="outline" size="sm" onClick={copyReferralCode}>
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex flex-col gap-2">
              <Button className="w-full bg-blue-600 hover:bg-blue-700">
                <Share2 className="mr-2 h-4 w-4" /> Share on Social Media
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="border-gray-800 bg-gray-950">
          <CardHeader>
            <CardTitle>Referral Stats</CardTitle>
            <CardDescription>Track your referral performance</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-gray-900 rounded-md text-center">
                <p className="text-sm text-zinc-400">Total Referrals</p>
                <p className="text-2xl font-bold text-zinc-100">3</p>
              </div>
              <div className="p-4 bg-gray-900 rounded-md text-center">
                <p className="text-sm text-muted-foreground">Total Earned</p>
                <p className="text-2xl font-bold text-blue-500">0.0005 ETH</p>
              </div>
            </div>
            <div className="p-4 bg-gray-900 rounded-md">
              <p className="text-sm text-muted-foreground mb-2">Referral Tier</p>
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5 text-blue-500" />
                <span className="font-medium">Bronze Tier</span>
                <span className="text-xs text-muted-foreground ml-auto">3/5 to Silver</span>
              </div>
            </div>
            <div className="p-4 bg-gray-900 rounded-md">
              <p className="text-sm text-muted-foreground mb-2">Referral Benefits</p>
              <ul className="text-sm space-y-1">
                <li>• 10% of referred miners' rewards</li>
                <li>• Bonus hash rate for each referral</li>
                <li>• Tier upgrades with more referrals</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <Card className="border-gray-800 bg-gray-950 md:col-span-2">
          <CardHeader>
            <CardTitle>Your Referrals</CardTitle>
            <CardDescription>People who joined using your link</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border border-gray-800">
              <div className="grid grid-cols-4 gap-2 p-3 text-xs font-medium text-muted-foreground">
                <div>User</div>
                <div>Joined</div>
                <div>Mining Status</div>
                <div>You've Earned</div>
              </div>
              <div className="divide-y divide-gray-800">
                <div className="grid grid-cols-4 gap-2 p-3 text-sm">
                  <div className="font-medium">CryptoFan42</div>
                  <div>2 days ago</div>
                  <div className="text-green-500">Active</div>
                  <div className="text-blue-500">0.0003 ETH</div>
                </div>
                <div className="grid grid-cols-4 gap-2 p-3 text-sm">
                  <div className="font-medium">BlockchainBob</div>
                  <div>5 days ago</div>
                  <div className="text-green-500">Active</div>
                  <div className="text-blue-500">0.0001 ETH</div>
                </div>
                <div className="grid grid-cols-4 gap-2 p-3 text-sm">
                  <div className="font-medium">MinerJane</div>
                  <div>1 week ago</div>
                  <div className="text-red-500">Inactive</div>
                  <div className="text-blue-500">0.0001 ETH</div>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full">
              View All Referrals <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>

        <Card className="border-gray-800 bg-gray-950 md:col-span-2">
          <CardHeader>
            <CardTitle>Invite Friends</CardTitle>
            <CardDescription>Send invitations directly to your friends</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <Input placeholder="Enter email address" className="bg-gray-900 border-gray-800" />
              <Button className="bg-blue-600 hover:bg-blue-700">Send Invite</Button>
            </div>

            <div className="p-4 bg-gray-900 rounded-md">
              <p className="text-sm font-medium mb-2">Referral Tiers</p>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span>Bronze (0-4 referrals)</span>
                  <span>10% commission</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Silver (5-9 referrals)</span>
                  <span>12% commission</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Gold (10-19 referrals)</span>
                  <span>15% commission</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Platinum (20+ referrals)</span>
                  <span>20% commission</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

