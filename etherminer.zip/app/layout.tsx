import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { SiteHeader } from "@/components/site-header"
import { Toaster } from "@/components/ui/toaster"
import { AuthGuard } from "@/components/auth-guard"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "ETH Mining Simulator",
  description: "Advanced Ethereum mining simulation platform",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`${inter.className} bg-black text-zinc-100 min-h-screen flex flex-col`}>
        <AuthGuard>
          <SiteHeader />
          <main className="flex-1">{children}</main>
          <footer className="border-t border-gray-800 py-4">
            <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
              <p className="text-center text-sm text-muted-foreground">
                &copy; {new Date().getFullYear()} ETH Mining Simulator. All rights reserved.
              </p>
            </div>
          </footer>
          <Toaster />
        </AuthGuard>
      </body>
    </html>
  )
}



import './globals.css'