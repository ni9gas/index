import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Search, Trophy } from "lucide-react"

const topMiners = [
  { rank: 1, name: "CryptoKing", avatar: "/placeholder.svg?height=40&width=40", earnings: 0.0342, hashRate: 125.7 },
  { rank: 2, name: "BlockMaster", avatar: "/placeholder.svg?height=40&width=40", earnings: 0.0287, hashRate: 112.3 },
  { rank: 3, name: "HashQueen", avatar: "/placeholder.svg?height=40&width=40", earnings: 0.0231, hashRate: 98.5 },
  { rank: 4, name: "MinerPro", avatar: "/placeholder.svg?height=40&width=40", earnings: 0.0189, hashRate: 87.2 },
  { rank: 5, name: "EtherHunter", avatar: "/placeholder.svg?height=40&width=40", earnings: 0.0156, hashRate: 76.8 },
  { rank: 6, name: "BlockChaser", avatar: "/placeholder.svg?height=40&width=40", earnings: 0.0143, hashRate: 72.1 },
  { rank: 7, name: "CoinCollector", avatar: "/placeholder.svg?height=40&width=40", earnings: 0.0137, hashRate: 68.4 },
  { rank: 8, name: "HashMaster", avatar: "/placeholder.svg?height=40&width=40", earnings: 0.0129, hashRate: 65.2 },
  { rank: 9, name: "EtherDigger", avatar: "/placeholder.svg?height=40&width=40", earnings: 0.0118, hashRate: 61.7 },
  { rank: 10, name: "CryptoNinja", avatar: "/placeholder.svg?height=40&width=40", earnings: 0.0105, hashRate: 58.3 },
]

export default function LeaderboardPage() {
  return (
    <div className="flex min-h-screen flex-col bg-black text-white">
      <main className="flex-1">
        <section className="container grid items-center gap-6 pb-8 pt-6 md:py-10">
          <div className="flex max-w-[980px] flex-col items-start gap-2">
            <h1 className="text-3xl font-extrabold leading-tight tracking-tighter md:text-4xl">
              Miner <span className="text-blue-500">Leaderboard</span>
            </h1>
            <p className="max-w-[700px] text-lg text-muted-foreground">
              See who's leading the mining race and where you stand.
            </p>
          </div>

          <div className="flex items-center justify-between">
            <div className="relative w-full max-w-sm">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search miners..."
                className="w-full bg-gray-900 pl-8 text-white border-gray-800"
              />
            </div>
            <Tabs defaultValue="all-time" className="w-[400px]">
              <TabsList className="grid w-full grid-cols-3 bg-gray-900">
                <TabsTrigger value="all-time">All Time</TabsTrigger>
                <TabsTrigger value="monthly">Monthly</TabsTrigger>
                <TabsTrigger value="weekly">Weekly</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          <div className="grid gap-6 md:grid-cols-3">
            <Card className="border-gray-800 bg-gray-950 col-span-2">
              <CardHeader>
                <CardTitle>Top Miners</CardTitle>
                <CardDescription>Ranked by total ETH earned</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border border-gray-800">
                  <div className="grid grid-cols-5 gap-2 p-3 text-xs font-medium text-muted-foreground">
                    <div>Rank</div>
                    <div className="col-span-2">Miner</div>
                    <div>Earnings</div>
                    <div>Hash Rate</div>
                  </div>
                  <div className="divide-y divide-gray-800">
                    {topMiners.map((miner) => (
                      <div key={miner.rank} className="grid grid-cols-5 gap-2 p-3 text-sm">
                        <div className="font-medium flex items-center">
                          {miner.rank <= 3 && <Trophy className="h-4 w-4 mr-1 text-yellow-500" />}
                          {miner.rank}
                        </div>
                        <div className="col-span-2 flex items-center gap-2">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={miner.avatar} alt={miner.name} />
                            <AvatarFallback>{miner.name.substring(0, 2)}</AvatarFallback>
                          </Avatar>
                          <span>{miner.name}</span>
                        </div>
                        <div className="text-blue-500">{miner.earnings} ETH</div>
                        <div>{miner.hashRate} MH/s</div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card className="border-gray-800 bg-gray-950">
                <CardHeader>
                  <CardTitle>Your Ranking</CardTitle>
                  <CardDescription>Current position on the leaderboard</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-6xl font-bold text-blue-500">#42</div>
                      <p className="text-sm text-muted-foreground mt-1">Out of 1,247 miners</p>
                    </div>
                  </div>
                  <div className="p-4 bg-gray-900 rounded-md">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm">To next rank</span>
                      <span className="text-xs text-muted-foreground">0.0004 ETH more</span>
                    </div>
                    <div className="w-full h-2 bg-gray-800 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500 rounded-full" style={{ width: "65%" }}></div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-gray-800 bg-gray-950">
                <CardHeader>
                  <CardTitle>Mining Achievements</CardTitle>
                  <CardDescription>Milestones you've reached</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 bg-gray-900 rounded-md text-center">
                      <p className="text-xs text-muted-foreground">First Block</p>
                      <p className="text-sm font-medium">Unlocked</p>
                    </div>
                    <div className="p-3 bg-gray-900 rounded-md text-center">
                      <p className="text-xs text-muted-foreground">0.01 ETH</p>
                      <p className="text-sm font-medium">Unlocked</p>
                    </div>
                    <div className="p-3 bg-gray-900 rounded-md text-center">
                      <p className="text-xs text-muted-foreground">24h Mining</p>
                      <p className="text-sm font-medium">Unlocked</p>
                    </div>
                    <div className="p-3 bg-gray-900 rounded-md text-center">
                      <p className="text-xs text-muted-foreground">Top 50</p>
                      <p className="text-sm font-medium">Unlocked</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}

