"use client"

import { useEffect, useRef, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { Cpu } from "lucide-react"
import { useAuthStore, type TelegramUser } from "@/lib/auth-store"

declare global {
  interface Window {
    TelegramLoginWidget?: {
      dataOnauth: (user: TelegramUser) => void
    }
  }
}

export default function LoginPage() {
  const { isLoggedIn, login } = useAuthStore()
  const router = useRouter()
  const telegramLoginButtonRef = useRef<HTMLDivElement>(null)
  const [termsAccepted, setTermsAccepted] = useState(false)

  useEffect(() => {
    if (isLoggedIn) {
      router.push("/dashboard")
    }
  }, [isLoggedIn, router])

  useEffect(() => {
    if (!telegramLoginButtonRef.current) return

    // Set up Telegram Login Widget
    const script = document.createElement("script")
    script.src = "https://telegram.org/js/telegram-widget.js?22"
    script.setAttribute("data-telegram-login", "ETHMinerSimBot") // Replace with your bot name
    script.setAttribute("data-size", "large")
    script.setAttribute("data-radius", "8")
    script.setAttribute("data-request-access", "write")
    script.setAttribute("data-userpic", "false")
    script.setAttribute("data-auth-url", `${window.location.origin}/dashboard`)
    script.async = true

    // Clean up any existing buttons
    telegramLoginButtonRef.current.innerHTML = ""
    telegramLoginButtonRef.current.appendChild(script)

    // Handle the login callback
    window.TelegramLoginWidget = {
      dataOnauth: (user: TelegramUser) => {
        login(user)
        router.push("/dashboard")
      },
    }

    return () => {
      // Clean up
      if (telegramLoginButtonRef.current) {
        telegramLoginButtonRef.current.innerHTML = ""
      }
    }
  }, [login, router])

  const handleDemoLogin = () => {
    if (!termsAccepted) {
      alert("Please accept the terms and conditions")
      return
    }

    // Create demo user
    const demoUser: TelegramUser = {
      id: 12345678,
      first_name: "Demo",
      last_name: "User",
      username: "demouser",
      photo_url: "https://t.me/i/userpic/320/demouser.jpg",
      auth_date: Math.floor(Date.now() / 1000),
      hash: "demo_hash_value",
    }

    login(demoUser)
    router.push("/dashboard")
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-[#1e2126] text-white">
      <div className="w-full max-w-md flex flex-col items-center gap-6 px-4">
        <p className="text-zinc-400">Welcome!</p>

        <div className="flex items-center gap-2">
          <Cpu className="h-8 w-8 text-blue-500" />
          <h1 className="text-3xl font-bold">ETHMiner</h1>
        </div>

        <div className="w-full">
          {/* This div will be replaced by the Telegram login button */}
          <div ref={telegramLoginButtonRef} className="flex justify-center mb-4">
            {/* Telegram Login Widget will be inserted here */}
          </div>

          {/* Demo login button styled like Telegram button */}
          <Button
            onClick={handleDemoLogin}
            className="w-full bg-[#3390ec] hover:bg-[#2d81d7] text-white py-2 px-4 rounded-md flex items-center justify-center gap-2"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M12 0C5.376 0 0 5.376 0 12C0 18.624 5.376 24 12 24C18.624 24 24 18.624 24 12C24 5.376 18.624 0 12 0ZM17.568 8.16C17.388 10.056 16.608 14.664 16.212 16.788C16.044 17.688 15.708 17.988 15.396 18.024C14.7 18.084 14.172 17.568 13.5 17.124C12.444 16.428 11.844 15.996 10.824 15.324C9.636 14.544 10.404 14.112 11.088 13.416C11.268 13.236 14.34 10.44 14.4 10.188C14.412 10.152 14.412 10.044 14.352 9.996C14.292 9.948 14.208 9.96 14.136 9.972C14.04 9.984 12.24 11.184 8.76 13.548C8.304 13.848 7.884 13.992 7.512 13.98C7.104 13.968 6.312 13.74 5.724 13.548C5.004 13.308 4.428 13.18 4.476 12.78C4.5 12.576 4.788 12.36 5.352 12.156C9.06 10.56 11.616 9.504 13.032 8.976C16.908 7.44 17.664 7.164 18.12 7.152C18.216 7.152 18.432 7.176 18.576 7.296C18.696 7.392 18.72 7.524 18.732 7.62C18.756 7.752 18.768 8.004 18.756 8.196C18.744 8.34 17.664 7.152 17.568 8.16Z"
                fill="white"
              />
            </svg>
            Demo Login
          </Button>

          <div className="flex items-center space-x-2 mt-6">
            <Checkbox
              id="terms"
              checked={termsAccepted}
              onCheckedChange={(checked) => setTermsAccepted(checked === true)}
              className="border-white/30 data-[state=checked]:bg-blue-500"
            />
            <label
              htmlFor="terms"
              className="text-sm text-zinc-300 leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              I accept the{" "}
              <Link href="#" className="text-blue-400 hover:underline">
                user agreement
              </Link>{" "}
              and all project rules
            </label>
          </div>
        </div>
      </div>
    </div>
  )
}

