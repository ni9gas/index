"use client"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Sliders, Trash2 } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { useMiningStore } from "@/lib/mining-store"
import { GpuAnimation } from "@/components/gpu-animation"

export default function MinersPage() {
  const {
    isActive,
    gpuCount,
    powerLimit,
    memoryBoost,
    coreBoost,
    autoTune,
    setPowerLimit,
    setMemoryBoost,
    setCoreBoost,
    setAutoTune,
    addGpu,
    removeGpu,
  } = useMiningStore()

  const handlePowerLimitChange = (value: number[]) => {
    setPowerLimit(value[0])
  }

  const handleMemoryBoostChange = (value: number[]) => {
    setMemoryBoost(value[0])
  }

  const handleCoreBoostChange = (value: number[]) => {
    setCoreBoost(value[0])
  }

  const handleAutoTuneChange = (checked: boolean) => {
    setAutoTune(checked)
    if (checked) {
      // Apply optimal settings
      setPowerLimit(80)
      setMemoryBoost(500)
      setCoreBoost(100)
      toast({
        title: "Auto-Tune Enabled",
        description: "Optimal settings have been applied.",
      })
    }
  }

  const handleAddGpu = () => {
    if (gpuCount < 8) {
      addGpu()
      toast({
        title: "GPU Added",
        description: `Now mining with ${gpuCount + 1} GPUs.`,
      })
    }
  }

  const handleRemoveGpu = () => {
    if (gpuCount > 1) {
      removeGpu()
      toast({
        title: "GPU Removed",
        description: `Now mining with ${gpuCount - 1} GPUs.`,
      })
    }
  }

  return (
    <div className="container py-6">
      <div className="flex flex-col gap-2 mb-6">
        <h1 className="text-3xl font-bold text-white">Miners Management</h1>
        <p className="text-zinc-400">Configure and optimize your mining hardware</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="border-gray-800 bg-gray-950 md:col-span-2">
          <CardHeader>
            <CardTitle>GPU Configuration</CardTitle>
            <CardDescription>Fine-tune your mining hardware settings</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="tuning" className="w-full">
              <TabsList className="grid w-full grid-cols-2 bg-gray-900">
                <TabsTrigger value="tuning">Performance Tuning</TabsTrigger>
                <TabsTrigger value="hardware">Hardware Setup</TabsTrigger>
              </TabsList>
              <TabsContent value="tuning" className="space-y-6 pt-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-zinc-200">Power Limit ({powerLimit}%)</Label>
                    <span className="text-xs text-zinc-400">Higher = More Hash Rate, More Heat</span>
                  </div>
                  <Slider
                    value={[powerLimit]}
                    max={100}
                    min={50}
                    step={1}
                    onValueChange={handlePowerLimitChange}
                    disabled={autoTune}
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>Memory Clock Boost (+{memoryBoost} MHz)</Label>
                    <span className="text-xs text-muted-foreground">Higher = More Hash Rate</span>
                  </div>
                  <Slider
                    value={[memoryBoost]}
                    max={1500}
                    min={0}
                    step={50}
                    onValueChange={handleMemoryBoostChange}
                    disabled={autoTune}
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>Core Clock Boost (+{coreBoost} MHz)</Label>
                    <span className="text-xs text-muted-foreground">Higher = More Power Usage</span>
                  </div>
                  <Slider
                    value={[coreBoost]}
                    max={300}
                    min={0}
                    step={10}
                    onValueChange={handleCoreBoostChange}
                    disabled={autoTune}
                  />
                </div>

                <div className="flex items-center justify-between pt-2">
                  <Label htmlFor="autotune">Auto-Tune</Label>
                  <Switch id="autotune" checked={autoTune} onCheckedChange={handleAutoTuneChange} />
                </div>
              </TabsContent>
              <TabsContent value="hardware" className="space-y-6 pt-4">
                <div className="flex items-center justify-between">
                  <Label>GPU Count</Label>
                  <div className="flex items-center gap-4">
                    <Button variant="outline" size="icon" onClick={handleRemoveGpu} disabled={gpuCount <= 1}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                    <span className="w-8 text-center">{gpuCount}</span>
                    <Button variant="outline" size="icon" onClick={handleAddGpu} disabled={gpuCount >= 8}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="p-4 bg-gray-900 rounded-md">
                    <div className="text-sm font-medium mb-2">GPU Model</div>
                    <div className="text-sm text-muted-foreground">NVIDIA RTX 4080</div>
                  </div>
                  <div className="p-4 bg-gray-900 rounded-md">
                    <div className="text-sm font-medium mb-2">VRAM</div>
                    <div className="text-sm text-muted-foreground">16 GB GDDR6X</div>
                  </div>
                  <div className="p-4 bg-gray-900 rounded-md">
                    <div className="text-sm font-medium mb-2">Base Hash Rate</div>
                    <div className="text-sm text-muted-foreground">~95 MH/s</div>
                  </div>
                  <div className="p-4 bg-gray-900 rounded-md">
                    <div className="text-sm font-medium mb-2">Power Consumption</div>
                    <div className="text-sm text-muted-foreground">320W</div>
                  </div>
                </div>

                <div className="p-4 bg-gray-900 rounded-md">
                  <div className="text-sm font-medium mb-2">Driver Version</div>
                  <div className="text-sm text-muted-foreground">535.98.10</div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter>
            <Button className="w-full bg-blue-600 hover:bg-blue-700">Apply Settings</Button>
          </CardFooter>
        </Card>

        <Card className="border-gray-800 bg-gray-950">
          <CardHeader>
            <CardTitle>GPU Status</CardTitle>
            <CardDescription>Current hardware status</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-center mb-4">
              <div className="w-32 h-32 relative">
                <GpuAnimation isActive={isActive} />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-zinc-400">Status</span>
                <span className={isActive ? "text-green-500" : "text-red-500"}>{isActive ? "Mining" : "Idle"}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Temperature</span>
                <span>62°C</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Fan Speed</span>
                <span>65%</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Power Draw</span>
                <span>120W</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Efficiency</span>
                <span>0.30 MH/J</span>
              </div>
            </div>

            <div className="pt-2 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Uptime</span>
                <span>24h 35m</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Last Error</span>
                <span>None</span>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full">
              <Sliders className="h-4 w-4 mr-2" />
              Advanced Settings
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

