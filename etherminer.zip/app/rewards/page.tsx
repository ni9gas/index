import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Gift, RefreshCw, Star, Zap } from "lucide-react"

export default function RewardsPage() {
  return (
    <div className="flex min-h-screen flex-col bg-black text-white">
      <main className="flex-1">
        <section className="container grid items-center gap-6 pb-8 pt-6 md:py-10">
          <div className="flex max-w-[980px] flex-col items-start gap-2">
            <h1 className="text-3xl font-extrabold leading-tight tracking-tighter md:text-4xl">
              Daily <span className="text-blue-500">Rewards</span>
            </h1>
            <p className="max-w-[700px] text-lg text-muted-foreground">
              Complete tasks and claim bonuses to boost your mining operation.
            </p>
          </div>

          <Tabs defaultValue="daily" className="w-full">
            <TabsList className="grid w-full max-w-md grid-cols-3 bg-gray-900 mx-auto">
              <TabsTrigger value="daily">Daily</TabsTrigger>
              <TabsTrigger value="weekly">Weekly</TabsTrigger>
              <TabsTrigger value="achievements">Achievements</TabsTrigger>
            </TabsList>

            <TabsContent value="daily" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card className="border-gray-800 bg-gray-950">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2">
                      <Calendar className="h-5 w-5 text-blue-500" />
                      Daily Check-in
                    </CardTitle>
                    <CardDescription>Log in every day for bonus rewards</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="grid grid-cols-7 gap-2">
                      {[1, 2, 3, 4, 5, 6, 7].map((day) => (
                        <div
                          key={day}
                          className={`flex h-10 w-10 items-center justify-center rounded-md text-sm font-medium ${
                            day < 5 ? "bg-blue-500/20 text-blue-500" : "bg-gray-900 text-muted-foreground"
                          }`}
                        >
                          {day}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full bg-blue-600 hover:bg-blue-700">Claim Day 5 Reward</Button>
                  </CardFooter>
                </Card>

                <Card className="border-gray-800 bg-gray-950">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2">
                      <Zap className="h-5 w-5 text-blue-500" />
                      Mining Boost
                    </CardTitle>
                    <CardDescription>Temporary hash rate increase</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">+25% Hash Rate</span>
                        <span className="text-sm text-muted-foreground">45 min remaining</span>
                      </div>
                      <Progress value={45} className="h-2 bg-gray-800" indicatorClassName="bg-blue-500" />
                      <p className="text-xs text-muted-foreground">
                        Your mining operation is currently boosted. Next boost available in 3 hours.
                      </p>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full" disabled>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                      Boost Active
                    </Button>
                  </CardFooter>
                </Card>

                <Card className="border-gray-800 bg-gray-950">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2">
                      <Gift className="h-5 w-5 text-blue-500" />
                      Mystery Reward
                    </CardTitle>
                    <CardDescription>Claim a random bonus every day</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="flex items-center justify-center py-6">
                      <div className="relative h-24 w-24 rounded-md bg-gray-900 flex items-center justify-center">
                        <Gift className="h-12 w-12 text-blue-500" />
                        <div className="absolute -top-2 -right-2 flex h-6 w-6 items-center justify-center rounded-full bg-blue-500 text-xs font-bold">
                          ?
                        </div>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full bg-blue-600 hover:bg-blue-700">Open Mystery Box</Button>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="weekly" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2">
                <Card className="border-gray-800 bg-gray-950">
                  <CardHeader>
                    <CardTitle>Weekly Mining Challenge</CardTitle>
                    <CardDescription>Mine continuously for 24 hours</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Progress</span>
                      <span className="text-sm text-muted-foreground">14.5/24 hours</span>
                    </div>
                    <Progress value={60} className="h-2 bg-gray-800" indicatorClassName="bg-blue-500" />
                    <p className="text-sm text-muted-foreground">Reward: 0.001 ETH bonus + 48-hour hash rate boost</p>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full" disabled>
                      Continue Mining to Complete
                    </Button>
                  </CardFooter>
                </Card>

                <Card className="border-gray-800 bg-gray-950">
                  <CardHeader>
                    <CardTitle>Referral Challenge</CardTitle>
                    <CardDescription>Invite 3 new miners this week</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Progress</span>
                      <span className="text-sm text-muted-foreground">1/3 referrals</span>
                    </div>
                    <Progress value={33} className="h-2 bg-gray-800" indicatorClassName="bg-blue-500" />
                    <p className="text-sm text-muted-foreground">
                      Reward: 0.0005 ETH bonus + 15% referral rate for 7 days
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full bg-blue-600 hover:bg-blue-700">Share Referral Link</Button>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="achievements" className="mt-6">
              <div className="grid gap-6 md:grid-cols-3">
                {[
                  {
                    title: "First Block",
                    description: "Mine your first simulated block",
                    icon: Star,
                    completed: true,
                    reward: "0.0001 ETH",
                  },
                  {
                    title: "Hash Master",
                    description: "Reach 50 MH/s hash rate",
                    icon: Zap,
                    completed: true,
                    reward: "0.0002 ETH",
                  },
                  {
                    title: "Social Miner",
                    description: "Refer 5 friends",
                    icon: Gift,
                    completed: false,
                    progress: 60,
                    reward: "0.0005 ETH",
                  },
                  {
                    title: "Crypto Whale",
                    description: "Earn a total of 0.01 ETH",
                    icon: Star,
                    completed: false,
                    progress: 23,
                    reward: "0.001 ETH",
                  },
                  {
                    title: "Leaderboard Legend",
                    description: "Reach top 10 on leaderboard",
                    icon: Star,
                    completed: false,
                    progress: 0,
                    reward: "0.002 ETH",
                  },
                  {
                    title: "Mining Marathon",
                    description: "Mine continuously for 7 days",
                    icon: Calendar,
                    completed: false,
                    progress: 15,
                    reward: "0.003 ETH",
                  },
                ].map((achievement, index) => (
                  <Card key={index} className="border-gray-800 bg-gray-950">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <achievement.icon
                          className={`h-5 w-5 ${achievement.completed ? "text-blue-500" : "text-muted-foreground"}`}
                        />
                        {achievement.title}
                      </CardTitle>
                      <CardDescription>{achievement.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {achievement.completed ? (
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-green-500">Completed</span>
                          <span className="text-sm font-medium text-blue-500">{achievement.reward}</span>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">Progress</span>
                            <span className="text-sm text-muted-foreground">{achievement.progress}%</span>
                          </div>
                          <Progress
                            value={achievement.progress}
                            className="h-2 bg-gray-800"
                            indicatorClassName="bg-blue-500"
                          />
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-muted-foreground">Reward:</span>
                            <span className="text-xs font-medium text-blue-500">{achievement.reward}</span>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </section>
      </main>
    </div>
  )
}

