"use client"

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useState } from "react"
import { toast } from "@/components/ui/use-toast"
import { useAuthStore } from "@/lib/auth-store"

export default function AccountSettingsPage() {
  const { user } = useAuthStore()
  const [username, setUsername] = useState(user?.username || "")
  const [email, setEmail] = useState("user@example.com")

  const handleSave = () => {
    toast({
      title: "Profile Updated",
      description: "Your profile information has been updated.",
    })
  }

  return (
    <div className="container py-6">
      <div className="flex flex-col gap-2 mb-6">
        <h1 className="text-3xl font-bold text-white">Account Settings</h1>
        <p className="text-zinc-400">Manage your profile and account preferences</p>
      </div>

      <div className="grid gap-6">
        <Card className="border-gray-800 bg-gray-950">
          <CardHeader>
            <CardTitle>Telegram Account</CardTitle>
            <CardDescription>You're signed in with Telegram</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
              <div className="rounded-full bg-blue-600 w-16 h-16 flex items-center justify-center overflow-hidden">
                {user?.photo_url ? (
                  <img
                    src={user.photo_url || "/placeholder.svg"}
                    alt={user.first_name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span className="text-xl font-bold text-white">{user?.first_name?.[0] || "U"}</span>
                )}
              </div>

              <div className="space-y-1">
                <h3 className="text-lg font-medium text-white">
                  {user?.first_name} {user?.last_name}
                </h3>
                {user?.username && <p className="text-sm text-zinc-400">@{user.username}</p>}
                <Badge variant="outline" className="bg-blue-500/10 text-blue-400 border-blue-500/20">
                  Telegram User
                </Badge>
              </div>
            </div>

            <div className="pt-2 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="bg-gray-900 border-gray-800"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-gray-900 border-gray-800"
                />
              </div>

              <div className="p-3 bg-gray-900 rounded-md">
                <p className="text-sm text-zinc-400">
                  Connected with Telegram on{" "}
                  {new Date(user?.auth_date ? user.auth_date * 1000 : Date.now()).toLocaleDateString()}
                </p>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col gap-2 sm:flex-row sm:justify-between">
            <Button onClick={handleSave} className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700">
              Save Changes
            </Button>

            <Button variant="outline" className="w-full sm:w-auto border-gray-800 hover:bg-gray-900 hover:text-white">
              Disconnect Telegram
            </Button>
          </CardFooter>
        </Card>

        <Card className="border-gray-800 bg-gray-950">
          <CardHeader>
            <CardTitle>Security Settings</CardTitle>
            <CardDescription>Manage your account security preferences</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-md">
              <p className="text-sm text-yellow-300">
                Your account is secured through Telegram authentication. No password is required.
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="two-factor">Two-Factor Authentication</Label>
              <div className="p-3 bg-gray-900 rounded-md flex justify-between items-center">
                <span className="text-sm text-zinc-400">Enable 2FA for additional security</span>
                <Button variant="outline" size="sm" className="border-gray-800 hover:bg-gray-800">
                  Set Up
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Login Sessions</Label>
              <div className="p-3 bg-gray-900 rounded-md">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm font-medium text-zinc-200">Current Session</p>
                    <p className="text-xs text-zinc-400">Started {new Date().toLocaleDateString()}</p>
                  </div>
                  <Badge variant="outline" className="bg-green-500/10 text-green-400 border-green-500/20">
                    Active
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="destructive" className="w-full">
              Delete Account
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

