"use client"

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Copy, Save, Settings, Wallet } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { useMiningStore } from "@/lib/mining-store"
import { useState } from "react"

export default function SettingsPage() {
  const { miningPool, algorithm, walletAddress, setMiningPool, setAlgorithm, setWalletAddress } = useMiningStore()

  const [notifications, setNotifications] = useState(true)
  const [autoStart, setAutoStart] = useState(false)
  const [darkMode, setDarkMode] = useState(true)
  const [gasLimit, setGasLimit] = useState("50")
  const [payoutThreshold, setPayoutThreshold] = useState("0.05")

  const copyWalletAddress = () => {
    navigator.clipboard.writeText(walletAddress)
    toast({
      title: "Wallet Address Copied",
      description: "Address copied to clipboard.",
    })
  }

  const saveSettings = () => {
    toast({
      title: "Settings Saved",
      description: "Your preferences have been updated.",
    })
  }

  return (
    <div className="container py-6">
      <div className="flex flex-col gap-2 mb-6">
        <h1 className="text-3xl font-bold text-white">Settings</h1>
        <p className="text-zinc-400">Configure your mining preferences and account settings</p>
      </div>

      <div className="grid gap-6">
        <Tabs defaultValue="mining" className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-3 bg-gray-900 mx-auto">
            <TabsTrigger value="mining">Mining</TabsTrigger>
            <TabsTrigger value="account">Account</TabsTrigger>
            <TabsTrigger value="app">Application</TabsTrigger>
          </TabsList>

          <TabsContent value="mining" className="mt-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card className="border-gray-800 bg-gray-950">
                <CardHeader>
                  <CardTitle>Mining Configuration</CardTitle>
                  <CardDescription>Configure your mining parameters</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="pool" className="text-zinc-200">
                      Mining Pool
                    </Label>
                    <Select value={miningPool} onValueChange={setMiningPool}>
                      <SelectTrigger className="bg-gray-900 border-gray-800">
                        <SelectValue placeholder="Select a mining pool" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-900 border-gray-800">
                        <SelectItem value="ethermine.org">ethermine.org</SelectItem>
                        <SelectItem value="f2pool.com">f2pool.com</SelectItem>
                        <SelectItem value="poolin.com">poolin.com</SelectItem>
                        <SelectItem value="hiveon.net">hiveon.net</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="algorithm" className="text-zinc-200">
                      Algorithm
                    </Label>
                    <Select value={algorithm} onValueChange={setAlgorithm}>
                      <SelectTrigger className="bg-gray-900 border-gray-800">
                        <SelectValue placeholder="Select an algorithm" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-900 border-gray-800">
                        <SelectItem value="ethash">ethash</SelectItem>
                        <SelectItem value="etchash">etchash</SelectItem>
                        <SelectItem value="kawpow">kawpow</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="wallet" className="text-zinc-200">
                        Wallet Address
                      </Label>
                      <Button variant="ghost" size="sm" onClick={copyWalletAddress}>
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                    <Input
                      id="wallet"
                      value={walletAddress}
                      onChange={(e) => setWalletAddress(e.target.value)}
                      className="bg-gray-900 border-gray-800 text-zinc-200"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="autostart">Auto-start Mining</Label>
                    <Switch id="autostart" checked={autoStart} onCheckedChange={setAutoStart} />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700" onClick={saveSettings}>
                    <Save className="mr-2 h-4 w-4" />
                    Save Mining Settings
                  </Button>
                </CardFooter>
              </Card>

              <Card className="border-gray-800 bg-gray-950">
                <CardHeader>
                  <CardTitle>Payout Settings</CardTitle>
                  <CardDescription>Configure your payment preferences</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="threshold">Payout Threshold (ETH)</Label>
                    <Input
                      id="threshold"
                      value={payoutThreshold}
                      onChange={(e) => setPayoutThreshold(e.target.value)}
                      className="bg-gray-900 border-gray-800"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="gas">Gas Price Limit (Gwei)</Label>
                    <Input
                      id="gas"
                      value={gasLimit}
                      onChange={(e) => setGasLimit(e.target.value)}
                      className="bg-gray-900 border-gray-800"
                    />
                  </div>

                  <div className="p-4 bg-gray-900 rounded-md">
                    <div className="flex items-center gap-2 mb-2">
                      <Wallet className="h-4 w-4 text-blue-500" />
                      <div className="text-sm font-medium">Connected Wallet</div>
                    </div>
                    <div className="text-xs text-muted-foreground break-all mb-2">{walletAddress}</div>
                    <Button variant="outline" size="sm" className="w-full">
                      Change Wallet
                    </Button>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700" onClick={saveSettings}>
                    <Save className="mr-2 h-4 w-4" />
                    Save Payout Settings
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="account" className="mt-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card className="border-gray-800 bg-gray-950">
                <CardHeader>
                  <CardTitle>Account Information</CardTitle>
                  <CardDescription>Manage your account details</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="username">Username</Label>
                    <Input id="username" value="CryptoMiner42" className="bg-gray-900 border-gray-800" />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input id="email" type="email" value="user@example.com" className="bg-gray-900 border-gray-800" />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <Input id="password" type="password" value="********" className="bg-gray-900 border-gray-800" />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700" onClick={saveSettings}>
                    <Save className="mr-2 h-4 w-4" />
                    Update Account
                  </Button>
                </CardFooter>
              </Card>

              <Card className="border-gray-800 bg-gray-950">
                <CardHeader>
                  <CardTitle>Notification Settings</CardTitle>
                  <CardDescription>Configure your notification preferences</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="notifications">Enable Notifications</Label>
                    <Switch id="notifications" checked={notifications} onCheckedChange={setNotifications} />
                  </div>

                  <div className="space-y-2">
                    <Label>Notification Types</Label>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Switch id="mining-alerts" checked={true} />
                        <Label htmlFor="mining-alerts">Mining Alerts</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch id="payout-alerts" checked={true} />
                        <Label htmlFor="payout-alerts">Payout Notifications</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch id="referral-alerts" checked={true} />
                        <Label htmlFor="referral-alerts">Referral Updates</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch id="system-alerts" checked={false} />
                        <Label htmlFor="system-alerts">System Announcements</Label>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700" onClick={saveSettings}>
                    <Save className="mr-2 h-4 w-4" />
                    Save Notification Settings
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="app" className="mt-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card className="border-gray-800 bg-gray-950">
                <CardHeader>
                  <CardTitle>Application Settings</CardTitle>
                  <CardDescription>Configure app behavior and appearance</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="darkmode">Dark Mode</Label>
                    <Switch id="darkmode" checked={darkMode} onCheckedChange={setDarkMode} />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="language">Language</Label>
                    <Select defaultValue="en">
                      <SelectTrigger className="bg-gray-900 border-gray-800">
                        <SelectValue placeholder="Select language" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-900 border-gray-800">
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="es">Spanish</SelectItem>
                        <SelectItem value="fr">French</SelectItem>
                        <SelectItem value="de">German</SelectItem>
                        <SelectItem value="ru">Russian</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="currency">Display Currency</Label>
                    <Select defaultValue="usd">
                      <SelectTrigger className="bg-gray-900 border-gray-800">
                        <SelectValue placeholder="Select currency" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-900 border-gray-800">
                        <SelectItem value="usd">USD ($)</SelectItem>
                        <SelectItem value="eur">EUR (€)</SelectItem>
                        <SelectItem value="gbp">GBP (£)</SelectItem>
                        <SelectItem value="jpy">JPY (¥)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700" onClick={saveSettings}>
                    <Save className="mr-2 h-4 w-4" />
                    Save App Settings
                  </Button>
                </CardFooter>
              </Card>

              <Card className="border-gray-800 bg-gray-950">
                <CardHeader>
                  <CardTitle>Advanced Settings</CardTitle>
                  <CardDescription>Configure advanced application options</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="telemetry">Share Anonymous Usage Data</Label>
                    <Switch id="telemetry" defaultChecked={true} />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="hardware">Enable Hardware Acceleration</Label>
                    <Switch id="hardware" defaultChecked={true} />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="updates">Automatic Updates</Label>
                    <Switch id="updates" defaultChecked={true} />
                  </div>

                  <div className="p-4 bg-gray-900 rounded-md">
                    <div className="flex items-center gap-2 mb-2">
                      <Settings className="h-4 w-4 text-blue-500" />
                      <div className="text-sm font-medium">Application Info</div>
                    </div>
                    <div className="space-y-1 text-xs text-muted-foreground">
                      <div>Version: 1.2.4</div>
                      <div>Build: 20250329</div>
                      <div>Last Updated: March 29, 2025</div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">
                    Reset All Settings
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

