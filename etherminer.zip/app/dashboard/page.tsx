"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Cpu, Zap, HardDrive, RefreshCw } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { GpuAnimation } from "@/components/gpu-animation"
import { HashRateChart } from "@/components/hashrate-chart"
import { useMiningStore } from "@/lib/mining-store"

export default function DashboardPage() {
  const {
    isActive,
    hashRate,
    miningProgress,
    gpuCount,
    powerUsage,
    temperature,
    efficiency,
    toggleMining,
    hashRateHistory,
    blocksMined,
    sharesAccepted,
    sharesRejected,
  } = useMiningStore()

  const formatHashRate = (rate: number) => {
    if (rate >= 1000) {
      return `${(rate / 1000).toFixed(2)} GH/s`
    }
    return `${rate.toFixed(1)} MH/s`
  }

  const handleToggleMining = () => {
    toggleMining()
    if (!isActive) {
      toast({
        title: "Mining Started",
        description: "Your simulated mining operation has begun.",
      })
    } else {
      toast({
        title: "Mining Paused",
        description: "Your simulated mining operation has been paused.",
      })
    }
  }

  return (
    <div className="container py-6">
      <div className="flex flex-col gap-2 mb-6">
        <h1 className="text-3xl font-bold text-white">Mining Dashboard</h1>
        <p className="text-zinc-400">Monitor and control your mining operation</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="border-gray-800 bg-gray-950 md:col-span-2">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Mining Status</CardTitle>
                <CardDescription className="text-zinc-400">Current operation status</CardDescription>
              </div>
              <Button
                variant={isActive ? "destructive" : "default"}
                onClick={handleToggleMining}
                className={isActive ? "bg-red-600 hover:bg-red-700" : "bg-blue-600 hover:bg-blue-700"}
              >
                {isActive ? "Stop Mining" : "Start Mining"}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-20 h-20 relative">
                    <GpuAnimation isActive={isActive} />
                  </div>
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Zap className="h-4 w-4 text-blue-500" />
                        <span className="text-sm font-medium">Hash Rate:</span>
                      </div>
                      <span className="text-sm font-bold text-blue-500">{formatHashRate(hashRate * gpuCount)}</span>
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm">Mining Progress</span>
                        <span className="text-xs text-muted-foreground">{miningProgress.toFixed(0)}%</span>
                      </div>
                      <Progress value={miningProgress} className="h-2 bg-gray-800" indicatorClassName="bg-blue-500" />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Cpu className="h-4 w-4 text-blue-500" />
                        <span className="text-sm font-medium">Status:</span>
                      </div>
                      <span className={`text-sm font-bold ${isActive ? "text-green-500" : "text-red-500"}`}>
                        {isActive ? "Active" : "Inactive"}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 bg-gray-900 rounded-md">
                    <div className="text-xs text-zinc-400 mb-1">Power Usage</div>
                    <div className="flex items-center justify-between">
                      <HardDrive className="h-4 w-4 text-blue-500" />
                      <span className="text-sm font-medium text-zinc-200">{powerUsage}W</span>
                    </div>
                  </div>
                  <div className="p-3 bg-gray-900 rounded-md">
                    <div className="text-xs text-zinc-400 mb-1">Temperature</div>
                    <div className="flex items-center justify-between">
                      <Zap className="h-4 w-4 text-blue-500" />
                      <span className="text-sm font-medium text-zinc-200">{temperature}°C</span>
                    </div>
                  </div>
                  <div className="p-3 bg-gray-900 rounded-md">
                    <div className="text-xs text-zinc-400 mb-1">Efficiency</div>
                    <div className="flex items-center justify-between">
                      <RefreshCw className="h-4 w-4 text-blue-500" />
                      <span className="text-sm font-medium text-zinc-200">{efficiency.toFixed(2)} MH/J</span>
                    </div>
                  </div>
                  <div className="p-3 bg-gray-900 rounded-md">
                    <div className="text-xs text-zinc-400 mb-1">GPUs</div>
                    <div className="flex items-center justify-between">
                      <Cpu className="h-4 w-4 text-blue-500" />
                      <span className="text-sm font-medium text-zinc-200">{gpuCount}x RTX 4080</span>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <HashRateChart data={hashRateHistory} />

                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div className="p-3 bg-gray-900 rounded-md">
                    <div className="text-xs text-zinc-400 mb-1">Blocks Mined</div>
                    <div className="text-sm font-medium text-zinc-200">{blocksMined}</div>
                  </div>
                  <div className="p-3 bg-gray-900 rounded-md">
                    <div className="text-xs text-zinc-400 mb-1">Shares</div>
                    <div className="text-sm font-medium text-zinc-200">
                      <span className="text-green-500">{sharesAccepted}</span>
                      <span className="text-muted-foreground mx-1">/</span>
                      <span className="text-red-500">{sharesRejected}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-gray-800 bg-gray-950">
          <CardHeader>
            <CardTitle>Quick Stats</CardTitle>
            <CardDescription className="text-zinc-400">Mining performance overview</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-zinc-400">Current Hash Rate</span>
                <span className="text-zinc-200">{formatHashRate(hashRate * gpuCount)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-zinc-400">Effective Hash Rate</span>
                <span className="text-zinc-200">{formatHashRate(hashRate * gpuCount * 0.98)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-zinc-400">Shares Accepted</span>
                <span className="text-zinc-200">{sharesAccepted}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-zinc-400">Shares Rejected</span>
                <span className="text-red-500">{sharesRejected}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-zinc-400">Accept Rate</span>
                <span className="text-zinc-200">
                  {sharesAccepted + sharesRejected > 0
                    ? ((sharesAccepted / (sharesAccepted + sharesRejected)) * 100).toFixed(2)
                    : 0}
                  %
                </span>
              </div>
            </div>

            <div className="pt-2 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-zinc-400">Mining Time</span>
                <span className="text-zinc-200">24h 35m</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-zinc-400">Uptime</span>
                <span className="text-zinc-200">98.7%</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-zinc-400">Pool</span>
                <span className="text-zinc-200">ethermine.org</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-zinc-400">Algorithm</span>
                <span className="text-zinc-200">ethash</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

