"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart3, Clock, Zap } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { useMiningStore } from "@/lib/mining-store"
import { HashRateChart } from "@/components/hashrate-chart"

export default function StatisticsPage() {
  const {
    hashRate,
    gpuCount,
    difficulty,
    networkHashRate,
    blocksMined,
    sharesAccepted,
    sharesRejected,
    lastBlockTime,
    isActive,
    hashRateHistory,
  } = useMiningStore()

  // Update the formatHashRate function to handle larger values
  const formatHashRate = (rate: number) => {
    if (rate >= 1000) {
      return `${(rate / 1000).toFixed(2)} GH/s`
    }
    return `${rate.toFixed(1)} MH/s`
  }

  const calculateAcceptRate = () => {
    const total = sharesAccepted + sharesRejected
    if (total === 0) return "0%"
    return `${((sharesAccepted / total) * 100).toFixed(2)}%`
  }

  // Update the calculateEstimatedEarnings function for more realistic earnings
  const calculateEstimatedEarnings = () => {
    // More realistic calculation based on hash rate and network difficulty
    const networkHashRateMH = networkHashRate * 1000 // Convert TH/s to MH/s
    const yourHashRate = hashRate * gpuCount
    const shareOfNetwork = yourHashRate / networkHashRateMH
    const dailyEthReward = 2.5 // Approximate ETH rewarded per day on the network
    const dailyEarning = dailyEthReward * shareOfNetwork

    return dailyEarning.toFixed(6)
  }

  return (
    <div className="container py-6">
      <div className="flex flex-col gap-2 mb-6">
        <h1 className="text-3xl font-bold text-white">Mining Statistics</h1>
        <p className="text-zinc-400">Detailed performance metrics and analytics</p>
      </div>

      <div className="grid gap-6">
        <Card className="border-gray-800 bg-gray-950">
          <CardHeader>
            <CardTitle className="text-white">Hash Rate Performance</CardTitle>
            <CardDescription className="text-zinc-400">Historical hash rate data</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <HashRateChart data={hashRateHistory} />
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
              <div className="p-4 bg-gray-900 rounded-md text-center">
                <div className="text-xs text-zinc-400 mb-1">Current</div>
                <div className="text-lg font-medium text-blue-400">{formatHashRate(hashRate * gpuCount)}</div>
              </div>
              <div className="p-4 bg-gray-900 rounded-md text-center">
                <div className="text-xs text-muted-foreground mb-1">Average</div>
                <div className="text-lg font-medium">{formatHashRate(hashRate * gpuCount * 0.98)}</div>
              </div>
              <div className="p-4 bg-gray-900 rounded-md text-center">
                <div className="text-xs text-muted-foreground mb-1">Peak</div>
                <div className="text-lg font-medium">{formatHashRate(hashRate * gpuCount * 1.05)}</div>
              </div>
              <div className="p-4 bg-gray-900 rounded-md text-center">
                <div className="text-xs text-muted-foreground mb-1">Efficiency</div>
                <div className="text-lg font-medium">0.38 MH/J</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="border-gray-800 bg-gray-950">
            <CardHeader>
              <CardTitle className="text-white">Performance Metrics</CardTitle>
              <CardDescription className="text-zinc-400">Mining performance statistics</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="shares" className="w-full">
                <TabsList className="grid w-full grid-cols-3 bg-gray-900">
                  <TabsTrigger value="shares">Shares</TabsTrigger>
                  <TabsTrigger value="blocks">Blocks</TabsTrigger>
                  <TabsTrigger value="uptime">Uptime</TabsTrigger>
                </TabsList>
                <TabsContent value="shares" className="space-y-4 pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 bg-gray-900 rounded-md text-center">
                      <div className="text-xs text-muted-foreground mb-1">Accepted</div>
                      <div className="text-2xl font-medium text-green-500">{sharesAccepted}</div>
                    </div>
                    <div className="p-4 bg-gray-900 rounded-md text-center">
                      <div className="text-xs text-muted-foreground mb-1">Rejected</div>
                      <div className="text-2xl font-medium text-red-500">{sharesRejected}</div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-zinc-400">Accept Rate</span>
                      <span className="text-zinc-200">{calculateAcceptRate()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Shares per Hour</span>
                      <span>{Math.round((sharesAccepted + sharesRejected) / 24)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Last Share</span>
                      <span>2 minutes ago</span>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="blocks" className="space-y-4 pt-4">
                  <div className="p-4 bg-gray-900 rounded-md text-center">
                    <div className="text-xs text-muted-foreground mb-1">Blocks Mined</div>
                    <div className="text-2xl font-medium text-blue-500">{blocksMined}</div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Last Block Found</span>
                      <span>{formatDistanceToNow(lastBlockTime, { addSuffix: true })}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Average Time Between Blocks</span>
                      <span>6h 12m</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Luck</span>
                      <span>98%</span>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="uptime" className="space-y-4 pt-4">
                  <div className="p-4 bg-gray-900 rounded-md text-center">
                    <div className="text-xs text-muted-foreground mb-1">Total Mining Time</div>
                    <div className="text-2xl font-medium">24h 35m</div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Uptime</span>
                      <span>98.7%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Last Restart</span>
                      <span>2 days ago</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Status</span>
                      <span className={isActive ? "text-green-500" : "text-red-500"}>
                        {isActive ? "Mining" : "Stopped"}
                      </span>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          <Card className="border-gray-800 bg-gray-950">
            <CardHeader>
              <CardTitle className="text-white">Network Statistics</CardTitle>
              <CardDescription className="text-zinc-400">Ethereum network metrics</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                {/* Update the network statistics display */}
                <div className="p-4 bg-gray-900 rounded-md">
                  <div className="flex items-center gap-2 mb-1">
                    <BarChart3 className="h-4 w-4 text-blue-500" />
                    <div className="text-xs text-muted-foreground">Network Difficulty</div>
                  </div>
                  <div className="text-lg font-medium">{difficulty.toFixed(2)} PH</div>
                </div>
                <div className="p-4 bg-gray-900 rounded-md">
                  <div className="flex items-center gap-2 mb-1">
                    <Zap className="h-4 w-4 text-blue-500" />
                    <div className="text-xs text-muted-foreground">Network Hash Rate</div>
                  </div>
                  <div className="text-lg font-medium">{(networkHashRate / 1000).toFixed(1)} PH/s</div>
                </div>
              </div>

              <div className="space-y-2">
                {/* Update the network share calculation */}
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Your Network Share</span>
                  <span>{(((hashRate * gpuCount) / networkHashRate) * 100).toFixed(8)}%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Block Time</span>
                  <span>13.2 seconds</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Gas Price</span>
                  <span>25 Gwei</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">ETH Price</span>
                  <span>$3,500.00</span>
                </div>
              </div>

              <div className="p-4 bg-gray-900 rounded-md">
                <div className="flex items-center gap-2 mb-1">
                  <Clock className="h-4 w-4 text-blue-500" />
                  <div className="text-xs text-muted-foreground">Estimated Earnings (Daily)</div>
                </div>
                <div className="text-lg font-medium text-blue-500">{calculateEstimatedEarnings()} ETH</div>
                <div className="text-xs text-muted-foreground mt-1">
                  ≈ ${(Number.parseFloat(calculateEstimatedEarnings()) * 3500).toFixed(2)}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

