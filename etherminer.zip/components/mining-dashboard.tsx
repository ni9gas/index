"use client"

import { useState, useEffect, useRef } from "react"
import { ArrowRight, ChevronDown, Copy, Cpu, Download, HardDrive, Settings, Sliders, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Slider } from "@/components/ui/slider"
import { GpuAnimation } from "@/components/gpu-animation"
import { LeaderboardTable } from "@/components/leaderboard-table"
import { toast } from "@/components/ui/use-toast"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { MiningStats } from "@/components/mining-stats"
import { HashRateChart } from "@/components/hashrate-chart"

export function MiningDashboard() {
  const [hashRate, setHashRate] = useState(45.7)
  const [miningProgress, setMiningProgress] = useState(0)
  const [earnings, setEarnings] = useState(0.0023)
  const [isActive, setIsActive] = useState(false)
  const [referralCode] = useState("ETH" + Math.random().toString(36).substring(2, 8).toUpperCase())
  const [powerUsage, setPowerUsage] = useState(120)
  const [temperature, setTemperature] = useState(62)
  const [efficiency, setEfficiency] = useState(85)
  const [powerLimit, setPowerLimit] = useState(80)
  const [memoryBoost, setMemoryBoost] = useState(500)
  const [coreBoost, setCoreBoost] = useState(100)
  const [autoTune, setAutoTune] = useState(true)
  const [miningPool, setMiningPool] = useState("ethermine.org")
  const [algorithm, setAlgorithm] = useState("ethash")
  const [gpuCount, setGpuCount] = useState(1)
  const [hashRateHistory, setHashRateHistory] = useState<number[]>([])
  const [blocksMined, setBlocksMined] = useState(0)
  const [sharesSubmitted, setSharesSubmitted] = useState(0)
  const [sharesAccepted, setSharesAccepted] = useState(0)
  const [sharesRejected, setSharesRejected] = useState(0)
  const [difficulty, setDifficulty] = useState(3.45)
  const [networkHashRate, setNetworkHashRate] = useState(872.3)
  const [lastBlockTime, setLastBlockTime] = useState(new Date())
  const [walletAddress, setWalletAddress] = useState("0x7F5EB5bB5cF88cfcEe9613368636f458800e62CB")

  const intervalRef = useRef<NodeJS.Timeout | null>(null)
  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const statsIntervalRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    // Initialize hash rate history with current value
    setHashRateHistory(Array(20).fill(hashRate))

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
      if (progressIntervalRef.current) clearInterval(progressIntervalRef.current)
      if (statsIntervalRef.current) clearInterval(statsIntervalRef.current)
    }
  }, [])

  useEffect(() => {
    if (!isActive) {
      if (intervalRef.current) clearInterval(intervalRef.current)
      if (progressIntervalRef.current) clearInterval(progressIntervalRef.current)
      if (statsIntervalRef.current) clearInterval(statsIntervalRef.current)
      return
    }

    // Simulate hash rate fluctuations
    intervalRef.current = setInterval(() => {
      const baseHashRate = 45 + memoryBoost / 100 + coreBoost / 200
      const adjustedHashRate = baseHashRate * (powerLimit / 100) * gpuCount
      const fluctuation = (Math.random() - 0.5) * 2
      const newHashRate = Number.parseFloat((adjustedHashRate + fluctuation).toFixed(1))

      setHashRate(newHashRate)
      setHashRateHistory((prev) => [...prev.slice(1), newHashRate])

      // Update related stats
      setPowerUsage(Math.round(120 * (powerLimit / 100) * gpuCount))
      setTemperature(Math.round(55 + powerLimit / 5 + Math.random() * 5))
      setEfficiency(Math.round(85 - powerLimit / 10 + Math.random() * 3))
    }, 2000)

    // Simulate mining progress
    progressIntervalRef.current = setInterval(() => {
      setMiningProgress((prev) => {
        if (prev >= 100) {
          // When progress reaches 100%, reset and add to earnings
          const baseEarning = 0.0001 * (hashRate / 50) * (difficulty / 3.5)
          setEarnings((e) => Number.parseFloat((e + baseEarning).toFixed(6)))
          setBlocksMined((b) => b + 1)
          return 0
        }
        return prev + hashRate / 50
      })
    }, 300)

    // Simulate other mining stats
    statsIntervalRef.current = setInterval(() => {
      setSharesSubmitted((prev) => prev + Math.floor(Math.random() * 3) + 1)
      setSharesAccepted((prev) => prev + Math.floor(Math.random() * 2) + 1)
      if (Math.random() > 0.95) {
        setSharesRejected((prev) => prev + 1)
      }

      if (Math.random() > 0.9) {
        setDifficulty((prev) => Number.parseFloat((prev + (Math.random() * 0.1 - 0.05)).toFixed(2)))
      }

      if (Math.random() > 0.8) {
        setNetworkHashRate((prev) => Number.parseFloat((prev + (Math.random() * 5 - 2.5)).toFixed(1)))
      }

      if (Math.random() > 0.7) {
        setLastBlockTime(new Date())
      }
    }, 5000)

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
      if (progressIntervalRef.current) clearInterval(progressIntervalRef.current)
      if (statsIntervalRef.current) clearInterval(statsIntervalRef.current)
    }
  }, [isActive, hashRate, powerLimit, memoryBoost, coreBoost, gpuCount, difficulty])

  const toggleMining = () => {
    setIsActive((prev) => !prev)
    if (!isActive) {
      toast({
        title: "Mining Started",
        description: "Your simulated mining operation has begun.",
      })
    } else {
      toast({
        title: "Mining Paused",
        description: "Your simulated mining operation has been paused.",
      })
    }
  }

  const copyReferralCode = () => {
    navigator.clipboard.writeText(referralCode)
    toast({
      title: "Referral Code Copied",
      description: "Share with friends to earn bonus rewards!",
    })
  }

  const copyWalletAddress = () => {
    navigator.clipboard.writeText(walletAddress)
    toast({
      title: "Wallet Address Copied",
      description: "Address copied to clipboard.",
    })
  }

  const handlePowerLimitChange = (value: number[]) => {
    setPowerLimit(value[0])
  }

  const handleMemoryBoostChange = (value: number[]) => {
    setMemoryBoost(value[0])
  }

  const handleCoreBoostChange = (value: number[]) => {
    setCoreBoost(value[0])
  }

  const handleAutoTuneChange = (checked: boolean) => {
    setAutoTune(checked)
    if (checked) {
      // Apply optimal settings
      setPowerLimit(80)
      setMemoryBoost(500)
      setCoreBoost(100)
      toast({
        title: "Auto-Tune Enabled",
        description: "Optimal settings have been applied.",
      })
    }
  }

  const addGpu = () => {
    if (gpuCount < 8) {
      setGpuCount((prev) => prev + 1)
      toast({
        title: "GPU Added",
        description: `Now mining with ${gpuCount + 1} GPUs.`,
      })
    }
  }

  const removeGpu = () => {
    if (gpuCount > 1) {
      setGpuCount((prev) => prev - 1)
      toast({
        title: "GPU Removed",
        description: `Now mining with ${gpuCount - 1} GPUs.`,
      })
    }
  }

  const formatHashRate = (rate: number) => {
    if (rate >= 1000) {
      return `${(rate / 1000).toFixed(2)} GH/s`
    }
    return `${rate.toFixed(1)} MH/s`
  }

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <div className="lg:col-span-2 flex flex-col gap-6">
        <Card className="border-gray-800 bg-gray-950">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Mining Dashboard</CardTitle>
                <CardDescription>Simulated Ethereum mining operation</CardDescription>
              </div>
              <Button
                variant={isActive ? "destructive" : "default"}
                onClick={toggleMining}
                className={isActive ? "bg-red-600 hover:bg-red-700" : "bg-blue-600 hover:bg-blue-700"}
              >
                {isActive ? "Stop Mining" : "Start Mining"}
              </Button>
            </div>
          </CardHeader>
          <CardContent className="pb-2">
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-20 h-20 relative">
                    <GpuAnimation isActive={isActive} />
                  </div>
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Zap className="h-4 w-4 text-blue-500" />
                        <span className="text-sm font-medium">Hash Rate:</span>
                      </div>
                      <span className="text-sm font-bold text-blue-500">{formatHashRate(hashRate * gpuCount)}</span>
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm">Mining Progress</span>
                        <span className="text-xs text-muted-foreground">{miningProgress.toFixed(0)}%</span>
                      </div>
                      <Progress value={miningProgress} className="h-2 bg-gray-800" indicatorClassName="bg-blue-500" />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Cpu className="h-4 w-4 text-blue-500" />
                        <span className="text-sm font-medium">Status:</span>
                      </div>
                      <span className={`text-sm font-bold ${isActive ? "text-green-500" : "text-red-500"}`}>
                        {isActive ? "Active" : "Inactive"}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 bg-gray-900 rounded-md">
                    <div className="text-xs text-muted-foreground mb-1">Power Usage</div>
                    <div className="flex items-center justify-between">
                      <HardDrive className="h-4 w-4 text-blue-500" />
                      <span className="text-sm font-medium">{powerUsage}W</span>
                    </div>
                  </div>
                  <div className="p-3 bg-gray-900 rounded-md">
                    <div className="text-xs text-muted-foreground mb-1">Temperature</div>
                    <div className="flex items-center justify-between">
                      <Zap className="h-4 w-4 text-blue-500" />
                      <span className="text-sm font-medium">{temperature}°C</span>
                    </div>
                  </div>
                  <div className="p-3 bg-gray-900 rounded-md">
                    <div className="text-xs text-muted-foreground mb-1">Efficiency</div>
                    <div className="flex items-center justify-between">
                      <Sliders className="h-4 w-4 text-blue-500" />
                      <span className="text-sm font-medium">{efficiency}%</span>
                    </div>
                  </div>
                  <div className="p-3 bg-gray-900 rounded-md">
                    <div className="text-xs text-muted-foreground mb-1">GPUs</div>
                    <div className="flex items-center justify-between">
                      <Cpu className="h-4 w-4 text-blue-500" />
                      <span className="text-sm font-medium">{gpuCount}x RTX 4080</span>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <HashRateChart data={hashRateHistory} />

                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div className="p-3 bg-gray-900 rounded-md">
                    <div className="text-xs text-muted-foreground mb-1">Blocks Mined</div>
                    <div className="text-sm font-medium">{blocksMined}</div>
                  </div>
                  <div className="p-3 bg-gray-900 rounded-md">
                    <div className="text-xs text-muted-foreground mb-1">Shares</div>
                    <div className="text-sm font-medium">
                      <span className="text-green-500">{sharesAccepted}</span>
                      <span className="text-muted-foreground mx-1">/</span>
                      <span className="text-red-500">{sharesRejected}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between pt-2">
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <Settings className="h-4 w-4 mr-2" />
                  Mining Settings
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-gray-950 text-white border-gray-800">
                <DialogHeader>
                  <DialogTitle>Mining Configuration</DialogTitle>
                  <DialogDescription>Adjust your mining parameters for optimal performance.</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="pool">Mining Pool</Label>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="outline" className="w-full justify-between">
                          {miningPool}
                          <ChevronDown className="h-4 w-4 ml-2" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent className="w-full bg-gray-900 border-gray-800">
                        <DropdownMenuItem onClick={() => setMiningPool("ethermine.org")}>
                          ethermine.org
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setMiningPool("f2pool.com")}>f2pool.com</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setMiningPool("poolin.com")}>poolin.com</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setMiningPool("hiveon.net")}>hiveon.net</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="algorithm">Algorithm</Label>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="outline" className="w-full justify-between">
                          {algorithm}
                          <ChevronDown className="h-4 w-4 ml-2" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent className="w-full bg-gray-900 border-gray-800">
                        <DropdownMenuItem onClick={() => setAlgorithm("ethash")}>ethash</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setAlgorithm("etchash")}>etchash</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setAlgorithm("kawpow")}>kawpow</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  <div className="grid gap-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="wallet">Wallet Address</Label>
                      <Button variant="ghost" size="sm" onClick={copyWalletAddress}>
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                    <Input
                      id="wallet"
                      value={walletAddress}
                      onChange={(e) => setWalletAddress(e.target.value)}
                      className="bg-gray-900 border-gray-800"
                    />
                  </div>

                  <div className="grid gap-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="gpus">GPU Count</Label>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm" onClick={removeGpu} disabled={gpuCount <= 1}>
                          -
                        </Button>
                        <span>{gpuCount}</span>
                        <Button variant="outline" size="sm" onClick={addGpu} disabled={gpuCount >= 8}>
                          +
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="autotune">Auto-Tune</Label>
                    <Switch id="autotune" checked={autoTune} onCheckedChange={handleAutoTuneChange} />
                  </div>
                </div>
                <DialogFooter>
                  <Button className="bg-blue-600 hover:bg-blue-700">Save Changes</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <Sliders className="h-4 w-4 mr-2" />
                  Tune GPU
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-gray-950 text-white border-gray-800">
                <DialogHeader>
                  <DialogTitle>GPU Tuning</DialogTitle>
                  <DialogDescription>Fine-tune your GPU settings for optimal mining performance.</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>Power Limit ({powerLimit}%)</Label>
                      <span className="text-xs text-muted-foreground">Higher = More Hash Rate, More Heat</span>
                    </div>
                    <Slider
                      defaultValue={[powerLimit]}
                      max={100}
                      min={50}
                      step={1}
                      onValueChange={handlePowerLimitChange}
                      disabled={autoTune}
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>Memory Clock Boost (+{memoryBoost} MHz)</Label>
                      <span className="text-xs text-muted-foreground">Higher = More Hash Rate</span>
                    </div>
                    <Slider
                      defaultValue={[memoryBoost]}
                      max={1500}
                      min={0}
                      step={50}
                      onValueChange={handleMemoryBoostChange}
                      disabled={autoTune}
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>Core Clock Boost (+{coreBoost} MHz)</Label>
                      <span className="text-xs text-muted-foreground">Higher = More Power Usage</span>
                    </div>
                    <Slider
                      defaultValue={[coreBoost]}
                      max={300}
                      min={0}
                      step={10}
                      onValueChange={handleCoreBoostChange}
                      disabled={autoTune}
                    />
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <Label htmlFor="autotune2">Auto-Tune</Label>
                    <Switch id="autotune2" checked={autoTune} onCheckedChange={handleAutoTuneChange} />
                  </div>
                </div>
                <DialogFooter>
                  <Button className="bg-blue-600 hover:bg-blue-700">Apply Settings</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </CardFooter>
        </Card>

        <Card className="border-gray-800 bg-gray-950">
          <CardHeader>
            <CardTitle>Mining Statistics</CardTitle>
            <CardDescription>Detailed performance metrics</CardDescription>
          </CardHeader>
          <CardContent>
            <MiningStats
              hashRate={hashRate * gpuCount}
              difficulty={difficulty}
              networkHashRate={networkHashRate}
              blocksMined={blocksMined}
              sharesAccepted={sharesAccepted}
              sharesRejected={sharesRejected}
              lastBlockTime={lastBlockTime}
              isActive={isActive}
            />
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col gap-6">
        <Card className="border-gray-800 bg-gray-950">
          <CardHeader>
            <CardTitle>Earnings</CardTitle>
            <CardDescription>Your simulated mining rewards</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Total Earned:</span>
              <span className="text-2xl font-bold text-blue-500">{earnings.toFixed(6)} ETH</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">USD Value:</span>
              <span className="text-lg font-medium">${(earnings * 3500).toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Daily Estimate:</span>
              <span className="text-sm font-medium">{((earnings / (blocksMined || 1)) * 144).toFixed(6)} ETH</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Weekly Estimate:</span>
              <span className="text-sm font-medium">{((earnings / (blocksMined || 1)) * 144 * 7).toFixed(6)} ETH</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Monthly Estimate:</span>
              <span className="text-sm font-medium">{((earnings / (blocksMined || 1)) * 144 * 30).toFixed(6)} ETH</span>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="w-full bg-blue-600 hover:bg-blue-700">
              Withdraw Earnings
              <Download className="ml-2 h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>

        <Card className="border-gray-800 bg-gray-950">
          <CardHeader>
            <CardTitle>Referral Program</CardTitle>
            <CardDescription>Invite friends and earn 10% of their mining rewards</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            <div className="flex items-center gap-2 p-2 bg-gray-900 rounded-md">
              <span className="text-sm font-medium truncate flex-1">{referralCode}</span>
              <Button variant="outline" size="sm" onClick={copyReferralCode}>
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-gray-900 rounded-md text-center">
                <p className="text-sm text-muted-foreground">Referrals</p>
                <p className="text-2xl font-bold">3</p>
              </div>
              <div className="p-4 bg-gray-900 rounded-md text-center">
                <p className="text-sm text-muted-foreground">Bonus Earned</p>
                <p className="text-2xl font-bold text-blue-500">0.0005 ETH</p>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full">
              View Referral Details
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>

        <Card className="border-gray-800 bg-gray-950">
          <CardHeader>
            <CardTitle>Top Miners</CardTitle>
          </CardHeader>
          <CardContent>
            <LeaderboardTable />
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full">
              View Full Leaderboard
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

