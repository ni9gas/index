"use client"

import { useEffect, useRef } from "react"

interface GpuAnimationProps {
  isActive: boolean
}

export function GpuAnimation({ isActive }: GpuAnimationProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    canvas.width = 120
    canvas.height = 120

    // GPU fan animation
    let rotation = 0
    let animationFrameId: number

    const drawGpu = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Draw GPU body
      ctx.fillStyle = "#1a1a1a"
      ctx.fillRect(10, 20, 100, 80)

      // Draw GPU details
      ctx.fillStyle = "#333"
      ctx.fillRect(15, 25, 90, 70)

      // Draw fan background
      ctx.fillStyle = "#0f0f0f"
      ctx.beginPath()
      ctx.arc(60, 60, 30, 0, Math.PI * 2)
      ctx.fill()

      // Draw fan blades
      ctx.save()
      ctx.translate(60, 60)
      ctx.rotate(rotation)

      const bladeCount = 6
      ctx.fillStyle = isActive ? "#3b82f6" : "#666"

      for (let i = 0; i < bladeCount; i++) {
        ctx.beginPath()
        ctx.moveTo(0, 0)
        ctx.arc(0, 0, 25, (i * 2 * Math.PI) / bladeCount, ((i + 0.5) * 2 * Math.PI) / bladeCount)
        ctx.fill()
      }

      // Draw fan center
      ctx.fillStyle = "#222"
      ctx.beginPath()
      ctx.arc(0, 0, 8, 0, Math.PI * 2)
      ctx.fill()

      ctx.restore()

      // Draw GPU lights
      ctx.fillStyle = isActive ? "#3b82f6" : "#333"
      ctx.fillRect(20, 30, 5, 5)

      // Draw GPU connector
      ctx.fillStyle = "#222"
      ctx.fillRect(10, 100, 100, 10)

      if (isActive) {
        rotation += 0.1
        animationFrameId = requestAnimationFrame(drawGpu)
      }
    }

    drawGpu()

    if (isActive) {
      animationFrameId = requestAnimationFrame(drawGpu)
    }

    return () => {
      cancelAnimationFrame(animationFrameId)
    }
  }, [isActive])

  return <canvas ref={canvasRef} className="w-full h-full" />
}

