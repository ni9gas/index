"use client"

import { useEffect, useRef } from "react"

interface HashRateChartProps {
  data: number[]
}

export function HashRateChart({ data }: HashRateChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    canvas.width = canvas.offsetWidth
    canvas.height = canvas.offsetHeight

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Draw background
    ctx.fillStyle = "#111"
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // Draw grid lines
    ctx.strokeStyle = "#333"
    ctx.lineWidth = 1

    // Vertical grid lines
    const verticalLines = 10
    for (let i = 1; i < verticalLines; i++) {
      const x = (canvas.width / verticalLines) * i
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, canvas.height)
      ctx.stroke()
    }

    // Horizontal grid lines
    const horizontalLines = 5
    for (let i = 1; i < horizontalLines; i++) {
      const y = (canvas.height / horizontalLines) * i
      ctx.beginPath()
      ctx.moveTo(0, y)
      ctx.lineTo(canvas.width, y)
      ctx.stroke()
    }

    // Find min and max values for scaling
    const minValue = Math.min(...data) * 0.9
    const maxValue = Math.max(...data) * 1.1

    // Draw hash rate line
    ctx.strokeStyle = "#3b82f6"
    ctx.lineWidth = 2

    ctx.beginPath()

    // Start at the first data point
    const pointWidth = canvas.width / (data.length - 1)

    data.forEach((value, index) => {
      // Scale the value to fit the canvas height
      const scaledValue = canvas.height - ((value - minValue) / (maxValue - minValue)) * canvas.height

      if (index === 0) {
        ctx.moveTo(0, scaledValue)
      } else {
        ctx.lineTo(index * pointWidth, scaledValue)
      }
    })

    ctx.stroke()

    // Add gradient fill under the line
    const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height)
    gradient.addColorStop(0, "rgba(59, 130, 246, 0.5)")
    gradient.addColorStop(1, "rgba(59, 130, 246, 0)")

    ctx.fillStyle = gradient
    ctx.beginPath()

    // Start at the bottom left
    ctx.moveTo(0, canvas.height)

    // Draw the line again
    data.forEach((value, index) => {
      const scaledValue = canvas.height - ((value - minValue) / (maxValue - minValue)) * canvas.height
      ctx.lineTo(index * pointWidth, scaledValue)
    })

    // Complete the path to the bottom right
    ctx.lineTo(canvas.width, canvas.height)
    ctx.closePath()
    ctx.fill()

    // Draw min and max labels
    ctx.fillStyle = "#d4d4d8" // zinc-300
    ctx.font = "10px sans-serif"
    ctx.fillText(`${Math.round(maxValue)} MH/s`, 5, 15)
    ctx.fillText(`${Math.round(minValue)} MH/s`, 5, canvas.height - 5)
  }, [data])

  return (
    <div className="w-full h-full bg-gray-900 rounded-md overflow-hidden">
      <canvas ref={canvasRef} className="w-full h-full" />
    </div>
  )
}

