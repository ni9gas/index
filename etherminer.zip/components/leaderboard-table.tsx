import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const leaderboardData = [
  { rank: 1, name: "CryptoKing", avatar: "/placeholder.svg?height=32&width=32", earnings: 0.0342, hashRate: 125.7 },
  { rank: 2, name: "BlockMaster", avatar: "/placeholder.svg?height=32&width=32", earnings: 0.0287, hashRate: 112.3 },
  { rank: 3, name: "HashQueen", avatar: "/placeholder.svg?height=32&width=32", earnings: 0.0231, hashRate: 98.5 },
  { rank: 4, name: "MinerPro", avatar: "/placeholder.svg?height=32&width=32", earnings: 0.0189, hashRate: 87.2 },
  { rank: 5, name: "EtherHunter", avatar: "/placeholder.svg?height=32&width=32", earnings: 0.0156, hashRate: 76.8 },
]

export function LeaderboardTable() {
  return (
    <div className="space-y-4">
      <div className="rounded-md border border-gray-800">
        <div className="grid grid-cols-4 gap-2 p-3 text-xs font-medium text-muted-foreground">
          <div>Rank</div>
          <div>Miner</div>
          <div>Earnings</div>
          <div>Hash Rate</div>
        </div>
        <div className="divide-y divide-gray-800">
          {leaderboardData.map((item) => (
            <div key={item.rank} className="grid grid-cols-4 gap-2 p-3 text-sm">
              <div className="font-medium">{item.rank}</div>
              <div className="flex items-center gap-2">
                <Avatar className="h-6 w-6">
                  <AvatarImage src={item.avatar} alt={item.name} />
                  <AvatarFallback>{item.name.substring(0, 2)}</AvatarFallback>
                </Avatar>
                <span>{item.name}</span>
              </div>
              <div className="text-blue-500">{item.earnings} ETH</div>
              <div>{item.hashRate} MH/s</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

