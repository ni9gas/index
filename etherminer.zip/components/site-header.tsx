"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Bell, Menu, LogOut, Cpu, Zap, BarChart3, Settings, DollarSign, Users, LayoutGrid } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useAuthStore } from "@/lib/auth-store"

export function SiteHeader() {
  const pathname = usePathname()
  const { user, logout } = useAuthStore()

  // Hide header on login page
  if (pathname === "/login") return null

  const navItems = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutGrid },
    { href: "/miners", label: "Miners", icon: Cpu },
    { href: "/statistics", label: "Statistics", icon: BarChart3 },
    { href: "/earnings", label: "Earnings", icon: DollarSign },
    { href: "/referrals", label: "Referrals", icon: Users },
    { href: "/settings", label: "Settings", icon: Settings },
  ]

  return (
    <header className="sticky top-0 z-40 w-full border-b border-gray-800 bg-black/95 backdrop-blur">
      <div className="container flex h-16 items-center">
        <div className="mr-4 flex">
          <Link href="/dashboard" className="mr-6 flex items-center space-x-2">
            <Cpu className="h-6 w-6 text-blue-500" />
            <span className="hidden font-bold sm:inline-block">
              ETH<span className="text-blue-500">Miner</span>
            </span>
          </Link>
          <nav className="hidden gap-6 md:flex">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`text-sm font-medium transition-colors hover:text-blue-400 flex items-center gap-1 ${
                  pathname === item.href ? "text-blue-400" : "text-zinc-300"
                }`}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
        <div className="flex flex-1 items-center justify-end space-x-4">
          <div className="hidden md:flex items-center gap-4 mr-4">
            <div className="flex items-center gap-1 text-sm">
              <Zap className="h-4 w-4 text-blue-500" />
              <span className="text-zinc-400">Network:</span>
              <span className="font-medium text-zinc-200">872.3 PH/s</span>
            </div>
            <div className="flex items-center gap-1 text-sm">
              <BarChart3 className="h-4 w-4 text-blue-500" />
              <span className="text-zinc-400">Difficulty:</span>
              <span className="font-medium text-zinc-200">12.45 PH</span>
            </div>
          </div>
          <nav className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-blue-500 text-[10px]">
                3
              </span>
            </Button>

            {/* User profile dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user?.photo_url} alt={user?.first_name || "User"} />
                    <AvatarFallback className="bg-blue-900">{user?.first_name?.[0] || "U"}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56 bg-gray-900 border-gray-800" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none text-white">
                      {user?.first_name} {user?.last_name}
                    </p>
                    <p className="text-xs leading-none text-zinc-400">@{user?.username || "user"}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator className="bg-gray-800" />
                <DropdownMenuItem
                  className="text-zinc-200 focus:bg-gray-800 focus:text-white cursor-pointer"
                  onClick={() => logout()}
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="bg-black text-white">
                <nav className="flex flex-col gap-4 mt-8">
                  {navItems.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={`text-sm font-medium transition-colors hover:text-blue-400 flex items-center gap-2 ${
                        pathname === item.href ? "text-blue-400" : "text-zinc-300"
                      }`}
                    >
                      <item.icon className="h-5 w-5" />
                      {item.label}
                    </Link>
                  ))}
                  <Button variant="ghost" onClick={() => logout()} className="justify-start px-2 hover:text-red-400">
                    <LogOut className="h-5 w-5 mr-2" />
                    Log out
                  </Button>
                </nav>
              </SheetContent>
            </Sheet>
          </nav>
        </div>
      </div>
    </header>
  )
}

