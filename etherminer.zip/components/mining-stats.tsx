"use client"

import { formatDistanceToNow } from "date-fns"

interface MiningStatsProps {
  hashRate: number
  difficulty: number
  networkHashRate: number
  blocksMined: number
  sharesAccepted: number
  sharesRejected: number
  lastBlockTime: Date
  isActive: boolean
}

export function MiningStats({
  hashRate,
  difficulty,
  networkHashRate,
  blocksMined,
  sharesAccepted,
  sharesRejected,
  lastBlockTime,
  isActive,
}: MiningStatsProps) {
  const formatHashRate = (rate: number) => {
    if (rate >= 1000) {
      return `${(rate / 1000).toFixed(2)} GH/s`
    }
    return `${rate.toFixed(1)} MH/s`
  }

  const calculateAcceptRate = () => {
    const total = sharesAccepted + sharesRejected
    if (total === 0) return "0%"
    return `${((sharesAccepted / total) * 100).toFixed(2)}%`
  }

  const calculateEstimatedEarnings = () => {
    // Simple calculation based on hash rate and network difficulty
    const dailyBlocks = 6500 // Approximate Ethereum blocks per day
    const networkReward = 2 // ETH per block
    const yourShare = hashRate / (networkHashRate * 1000000) // Your share of network hash rate

    const dailyEarning = dailyBlocks * networkReward * yourShare
    return dailyEarning.toFixed(6)
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      <div className="space-y-2">
        <h3 className="text-sm font-medium">Performance</h3>
        <div className="space-y-1">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Current Hash Rate</span>
            <span>{formatHashRate(hashRate)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Effective Hash Rate</span>
            <span>{formatHashRate(hashRate * 0.98)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Shares Accepted</span>
            <span>{sharesAccepted}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Shares Rejected</span>
            <span className="text-red-500">{sharesRejected}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Accept Rate</span>
            <span>{calculateAcceptRate()}</span>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <h3 className="text-sm font-medium">Network</h3>
        <div className="space-y-1">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Network Difficulty</span>
            <span>{difficulty.toFixed(2)} PH</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Network Hash Rate</span>
            <span>{networkHashRate.toFixed(1)} TH/s</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Last Block Found</span>
            <span>{formatDistanceToNow(lastBlockTime, { addSuffix: true })}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Your Network Share</span>
            <span>{((hashRate / (networkHashRate * 1000000)) * 100).toFixed(8)}%</span>
          </div>
        </div>
      </div>

      <div className="space-y-2 md:col-span-2 lg:col-span-1">
        <h3 className="text-sm font-medium">Earnings Estimate</h3>
        <div className="space-y-1">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Per Hour</span>
            <span>{(Number.parseFloat(calculateEstimatedEarnings()) / 24).toFixed(6)} ETH</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Per Day</span>
            <span>{calculateEstimatedEarnings()} ETH</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Per Week</span>
            <span>{(Number.parseFloat(calculateEstimatedEarnings()) * 7).toFixed(6)} ETH</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Per Month</span>
            <span>{(Number.parseFloat(calculateEstimatedEarnings()) * 30).toFixed(6)} ETH</span>
          </div>
          <div className="flex justify-between text-sm font-medium">
            <span className="text-muted-foreground">Status</span>
            <span className={isActive ? "text-green-500" : "text-red-500"}>{isActive ? "Mining" : "Stopped"}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

