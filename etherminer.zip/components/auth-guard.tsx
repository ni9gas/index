"use client"

import type React from "react"

import { useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"
import { useAuthStore } from "@/lib/auth-store"

interface AuthGuardProps {
  children: React.ReactNode
}

export function AuthGuard({ children }: AuthGuardProps) {
  const { isLoggedIn } = useAuthStore()
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    // Skip for login page to avoid redirection loop
    if (pathname === "/login") return

    // Redirect to login if not authenticated
    if (!isLoggedIn) {
      router.push("/login")
    }
  }, [isLoggedIn, router, pathname])

  // If on login page or logged in, render children
  if (pathname === "/login" || isLoggedIn) {
    return <>{children}</>
  }

  // Return null during the redirect
  return null
}

