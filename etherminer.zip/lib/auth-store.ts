"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"

export interface TelegramUser {
  id: number
  first_name: string
  last_name?: string
  username?: string
  photo_url?: string
  auth_date: number
  hash: string
}

interface AuthState {
  isLoggedIn: boolean
  user: TelegramUser | null
  login: (userData: TelegramUser) => void
  logout: () => void
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      isLoggedIn: false,
      user: null,
      login: (userData: TelegramUser) => set({ isLoggedIn: true, user: userData }),
      logout: () => set({ isLoggedIn: false, user: null }),
    }),
    {
      name: "eth-miner-auth",
    },
  ),
)

