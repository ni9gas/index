"use client"

import { create } from "zustand"
import { useEffect } from "react"

interface MiningState {
  isActive: boolean
  hashRate: number
  miningProgress: number
  earnings: number
  powerUsage: number
  temperature: number
  efficiency: number
  powerLimit: number
  memoryBoost: number
  coreBoost: number
  autoTune: boolean
  miningPool: string
  algorithm: string
  gpuCount: number
  hashRateHistory: number[]
  blocksMined: number
  sharesSubmitted: number
  sharesAccepted: number
  sharesRejected: number
  difficulty: number
  networkHashRate: number
  lastBlockTime: Date
  walletAddress: string

  toggleMining: () => void
  setPowerLimit: (value: number) => void
  setMemoryBoost: (value: number) => void
  setCoreBoost: (value: number) => void
  setAutoTune: (value: boolean) => void
  setMiningPool: (value: string) => void
  setAlgorithm: (value: string) => void
  addGpu: () => void
  removeGpu: () => void
  setWalletAddress: (value: string) => void
}

export const useMiningStore = create<MiningState>((set, get) => ({
  isActive: false,
  hashRate: 95.7, // Updated to a more realistic base hash rate for RTX 4080
  miningProgress: 0,
  earnings: 0.0023,
  powerUsage: 320, // Updated to more realistic power usage
  temperature: 62,
  efficiency: 0.3, // Updated to MH/J (megahash per joule)
  powerLimit: 80,
  memoryBoost: 500,
  coreBoost: 100,
  autoTune: true,
  miningPool: "ethermine.org",
  algorithm: "ethash",
  gpuCount: 1,
  hashRateHistory: Array(20).fill(95.7), // Updated initial history
  blocksMined: 0,
  sharesSubmitted: 0,
  sharesAccepted: 0,
  sharesRejected: 0,
  difficulty: 12.45, // Updated to more realistic network difficulty
  networkHashRate: 872300, // Updated to TH/s for the entire network
  lastBlockTime: new Date(),
  walletAddress: "0x7F5EB5bB5cF88cfcEe9613368636f458800e62CB",

  // Rest of the code remains the same
  toggleMining: () => {
    const isCurrentlyActive = get().isActive

    set({ isActive: !isCurrentlyActive })

    if (!isCurrentlyActive) {
      // Start mining simulation
      startMiningSimulation()
    } else {
      // Stop mining simulation
      stopMiningSimulation()
    }
  },

  setPowerLimit: (value) => set({ powerLimit: value }),
  setMemoryBoost: (value) => set({ memoryBoost: value }),
  setCoreBoost: (value) => set({ coreBoost: value }),
  setAutoTune: (value) => set({ autoTune: value }),
  setMiningPool: (value) => set({ miningPool: value }),
  setAlgorithm: (value) => set({ algorithm: value }),
  addGpu: () => set((state) => ({ gpuCount: state.gpuCount + 1 })),
  removeGpu: () => set((state) => ({ gpuCount: Math.max(1, state.gpuCount - 1) })),
  setWalletAddress: (value) => set({ walletAddress: value }),
}))

// Global interval references
let hashRateInterval: NodeJS.Timeout | null = null
let progressInterval: NodeJS.Timeout | null = null
let statsInterval: NodeJS.Timeout | null = null

// Update the mining simulation to use more realistic calculations
function startMiningSimulation() {
  const store = useMiningStore.getState()

  // Simulate hash rate fluctuations
  hashRateInterval = setInterval(() => {
    const state = useMiningStore.getState()
    // More realistic hash rate calculation based on GPU tuning
    const baseHashRate = 95 + state.memoryBoost / 100 + state.coreBoost / 200
    const adjustedHashRate = baseHashRate * (state.powerLimit / 100)
    const fluctuation = (Math.random() - 0.5) * 2
    const newHashRate = Number.parseFloat((adjustedHashRate + fluctuation).toFixed(1))

    // Update power usage based on power limit
    const basePowerUsage = 320 // Base power usage for RTX 4080
    const actualPowerUsage = Math.round(basePowerUsage * (state.powerLimit / 100) * state.gpuCount)

    // Calculate efficiency in MH/J (megahash per joule)
    const efficiency = Number.parseFloat((newHashRate / actualPowerUsage).toFixed(2))

    useMiningStore.setState({
      hashRate: newHashRate,
      hashRateHistory: [...state.hashRateHistory.slice(1), newHashRate],
      powerUsage: actualPowerUsage,
      temperature: Math.round(55 + state.powerLimit / 5 + Math.random() * 5),
      efficiency: efficiency,
    })
  }, 2000)

  // Simulate mining progress - adjusted for more realistic hash rates
  progressInterval = setInterval(() => {
    const state = useMiningStore.getState()

    if (state.miningProgress >= 100) {
      // When progress reaches 100%, reset and add to earnings
      // More realistic earnings calculation based on hash rate and network difficulty
      const networkHashRateMH = state.networkHashRate * 1000 // Convert TH/s to MH/s
      const yourHashRate = state.hashRate * state.gpuCount
      const shareOfNetwork = yourHashRate / networkHashRateMH
      const dailyEthReward = 2.5 // Approximate ETH rewarded per day on the network
      const yourDailyReward = dailyEthReward * shareOfNetwork
      const rewardPerBlock = yourDailyReward / 144 // Assuming ~144 blocks per day for simulation

      useMiningStore.setState({
        miningProgress: 0,
        earnings: Number.parseFloat((state.earnings + rewardPerBlock).toFixed(6)),
        blocksMined: state.blocksMined + 1,
      })
    } else {
      // Progress speed based on hash rate (higher hash rate = faster progress)
      const progressIncrement = (state.hashRate * state.gpuCount) / 1000
      useMiningStore.setState({
        miningProgress: state.miningProgress + progressIncrement,
      })
    }
  }, 300)

  // Rest of the simulation code remains the same
  statsInterval = setInterval(() => {
    const state = useMiningStore.getState()

    useMiningStore.setState({
      sharesSubmitted: state.sharesSubmitted + Math.floor(Math.random() * 3) + 1,
      sharesAccepted: state.sharesAccepted + Math.floor(Math.random() * 2) + 1,
      sharesRejected: Math.random() > 0.95 ? state.sharesRejected + 1 : state.sharesRejected,
      difficulty:
        Math.random() > 0.9
          ? Number.parseFloat((state.difficulty + (Math.random() * 0.1 - 0.05)).toFixed(2))
          : state.difficulty,
      networkHashRate:
        Math.random() > 0.8
          ? Number.parseFloat((state.networkHashRate + (Math.random() * 500 - 250)).toFixed(1))
          : state.networkHashRate,
      lastBlockTime: Math.random() > 0.7 ? new Date() : state.lastBlockTime,
    })
  }, 5000)
}

// Stop mining simulation
function stopMiningSimulation() {
  if (hashRateInterval) clearInterval(hashRateInterval)
  if (progressInterval) clearInterval(progressInterval)
  if (statsInterval) clearInterval(statsInterval)

  hashRateInterval = null
  progressInterval = null
  statsInterval = null
}

// Cleanup function for useEffect
export function useMiningCleanup() {
  useEffect(() => {
    return () => {
      stopMiningSimulation()
    }
  }, [])
}

