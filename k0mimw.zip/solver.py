import aiohttp
import asyncio
from typing import Optional

class CaptchaSolver:
    def __init__(self, api_key: str, session: aiohttp.ClientSession) -> None:
        self.api_key = api_key
        self.session = session
        self.site_key = "6LebcZAcAAAAAPq3wBuc51G3GEU07WS1vZPdeeN_"
        self.site_url = "https://app.cryptotaxcalculator.io"
        self.sleep_time = 1

    async def _create_task(self) -> Optional[str]:
        async with self.session.post("https://api.capsolver.com/createTask", json={
            "clientKey": self.api_key,
            "task": {
                "type": 'ReCaptchaV2TaskProxyLess',
                "websiteKey": self.site_key,
                "websiteURL": self.site_url
            }
        }) as response:
            task_response = await response.json()
            task_id = task_response.get("taskId")
            
            if not task_id:
                print("Failed to create task:", task_response)
                return None
            return task_id

    async def _get_task_result(self, task_id: str) -> Optional[str]:
        while True:
            await asyncio.sleep(self.sleep_time)
            async with self.session.post("https://api.capsolver.com/getTaskResult", json={
                "clientKey": self.api_key,
                "taskId": task_id
            }) as response:
                result_response = await response.json()
                status = result_response.get("status")
                if status == "ready":
                    return result_response.get("solution", {}).get('gRecaptchaResponse')
                elif status == "failed" or result_response.get("errorId"):
                    return None

    async def solve_captcha(self) -> Optional[str]:
        while True:
            task_id = await self._create_task()
            if not task_id:
                await asyncio.sleep(self.sleep_time)
                continue
            
            captcha_response = await self._get_task_result(task_id)
            if captcha_response:
                return captcha_response
            
            await asyncio.sleep(self.sleep_time)